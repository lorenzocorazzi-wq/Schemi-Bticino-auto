# Pacchetto di verifica dello schema a blocchi

Contenuto
- `schema_blocchi.json`: i blocchi in forma compatta. E' il file da correggere.
- `schema_blocchi.md`: lo stesso come albero leggibile, con misure e letture ambigue.
- `pagine/`: le pagine del PDF di progetto con i riquadri riconosciuti (rosso: articolo, blu: denominazione).
- `progetto_completo.json`: il progetto intero, per riaprirlo nel programma.

Come si controlla
1. Confrontare ogni blocco con la pagina indicata (`pagina`): articolo, denominazione, dati di targa.
2. Controllare da chi e' alimentato (`alimentato_da`, sigla del blocco a monte) e le misure.
3. Correggere solo quello che non coincide con il PDF di progetto; se un dato non e' leggibile, lasciarlo com'e'.

Come si reimporta
- Nel programma: "Apri blocchi" e scegliere il file corretto (anche questo zip).
- Le correzioni diventano proposte da confermare: il programma non le dichiara verificate.
