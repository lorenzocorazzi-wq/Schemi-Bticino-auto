import unwired_siblings as us


def _n(ident, x, parent=None, kind='MTD', page=18, status=None, trace=False):
    nodo = {'id': ident, 'kind': kind, 'parent': parent, 'evidence': {'page': page, 'axis': x},
            'connectionStatus': status or ('da_definire' if not parent else 'proposta_da_vettori_e_rimandi_reciproci')}
    if trace:
        nodo['evidence']['connectionTrace'] = {'method': 'x'}
    return nodo


def test_riserva_eredita_padre_del_vicino_a_sinistra():
    nodi = [_n('p', 50, kind='QS', page=7), _n('a', 263, 'p'), _n('b', 345, 'p'), _n('r1', 427), _n('r2', 508)]
    nodi[0]['evidence']['page'] = 18
    assert us.adotta(nodi) == ['r1', 'r2']
    assert nodi[3]['parent'] == 'p' and nodi[4]['parent'] == 'p'
    assert nodi[3]['connectionStatus'] == 'proposta_da_adiacenza'
    assert nodi[3]['connectionReview']['status'] == 'proposed'


def test_non_tocca_chi_ha_un_trace():
    nodi = [_n('p', 50, kind='QS'), _n('a', 263, 'p'), _n('r', 427, trace=True)]
    assert us.adotta(nodi) == []
    assert nodi[2]['parent'] is None


def test_tipo_diverso_non_adottato():
    nodi = [_n('p', 50, kind='QS'), _n('a', 263, 'p', kind='QS'), _n('r', 427, kind='MTD')]
    assert us.adotta(nodi) == []


def test_padre_su_altro_foglio_ammesso_per_barre_che_proseguono():
    nodi = [_n('p', 50, kind='QS', page=7), _n('a', 263, 'p', page=18), _n('r', 427, page=18)]
    assert us.adotta(nodi) == ['r']
    assert nodi[2]['parent'] == 'p'
