"""Un modulo largo (misura) con derivazioni: la corsia di ritorno sta dopo il modulo."""
import packing


def _nodi():
    return [
        {'id': 'a', 'parent': None, 'drawingWidth': 6, 'values': {}},
        {'id': 'b', 'parent': 'a', 'values': {}},
    ]


def test_corsia_dopo_modulo_largo():
    pagine, posizioni, _ = packing.plan_pages(_nodi())
    assert posizioni['a']['span'] == 6
    corsia = pagine[0]['lanes']['a']
    assert corsia == posizioni['a']['x'] + 25 * 6
    assert posizioni['b']['x'] > corsia


def test_corsia_modulo_stretto_invariata():
    nodi = _nodi()
    del nodi[0]['drawingWidth']
    pagine, posizioni, _ = packing.plan_pages(nodi)
    assert pagine[0]['lanes']['a'] == posizioni['a']['x'] + 25
