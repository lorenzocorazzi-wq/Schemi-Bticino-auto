import listino


def test_corregge_confusione_univoca():
    assert listino.correggi_ocr('M78230') == 'M7S230'
    assert listino.correggi_ocr('1724B250') == 'T724B250'
    assert listino.correggi_ocr('G701T/S5N') == 'G701T/35N'
    assert listino.correggi_ocr('FA0HB4') == 'F10HB4'


def test_codice_valido_non_modificato():
    assert listino.correggi_ocr('FT84C32') is None


def test_codice_sconosciuto_senza_correzione():
    assert listino.correggi_ocr('ZZZZZZ9') is None
