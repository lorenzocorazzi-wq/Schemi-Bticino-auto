import etichette as et

VOC = {'LABORATORIO': 50, 'RIUNIONI': 40, 'UFFICIO': 80, 'SECONDO': 30, 'PIANO': 60, 'BAGNO': 20, 'SERVIZIO': 25}
VALIDE = frozenset({'STAMPA', 'PRESIDENTE'})


def test_corregge_confusioni_ocr():
    testo, mod = et.correggi_etichetta('LABURAIURIU RLUNLUNI', VOC, VALIDE)
    assert testo == 'LABORATORIO RIUNIONI' and len(mod) == 2


def test_parola_valida_non_toccata():
    assert et.correggi_etichetta('ARCHIVIO E STAMPA', VOC, VALIDE)[0] == 'ARCHIVIO E STAMPA'
    assert et.correggi_etichetta('ZONA PRESIDENTE', VOC, VALIDE)[0] == 'ZONA PRESIDENTE'


def test_token_con_cifre_e_parole_corte_intatti():
    assert et.correggi_etichetta('QF 12A E 3P+N', VOC, VALIDE) == ('QF 12A E 3P+N', [])


def test_nessun_candidato_vicino():
    assert et.correggi_etichetta('XKQWZPLM', VOC, VALIDE)[0] == 'XKQWZPLM'


def test_vocabolario_reale_caricato():
    assert et.dominio() and 'RISERVA' in et.dominio()
    assert 'STAMPA' in et.generale()
