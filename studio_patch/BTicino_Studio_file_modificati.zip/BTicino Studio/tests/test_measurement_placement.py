import pytest

import measurement_placement as mp


def _progetto():
    return {
        'nodes': [
            {'id': 'g', 'sigla': 'QS1', 'parent': None, 'values': {'articolo': 'T714WF/630B'}},
            {'id': 'a', 'sigla': 'QF2', 'parent': 'g', 'values': {}},
            {'id': 'b', 'sigla': 'QF3', 'parent': 'g', 'values': {}},
        ],
        'measurementAssemblies': [{'id': 'm1', 'articleProposal': 'MFD41ORFCDT', 'measuredFeeder': 'g'}],
    }


def test_opzioni_propone_modo_dal_dispositivo():
    o = mp.opzioni(_progetto())
    assert [m['id'] for m in o['modi']] == ['upstream_general', 'downstream_general', 'downstream_device']
    assert not o['modi'][0]['disegnabile']
    assert o['misure'][0]['modoProposto'] == 'downstream_general'
    assert len(o['dispositivi']) == 3


def test_valle_generale_senza_dispositivo_usa_unico_generale():
    r = mp.posiziona(_progetto(), [{'misura': 'm1', 'modo': 'downstream_general'}])
    m = r['measurementAssemblies'][0]
    assert m['measuredFeeder'] == 'g' and m['assignmentSource'] == 'operator'
    assert m['placement'] == {'mode': 'downstream_general', 'deviceId': 'g'}


def test_valle_utenza_aggiunge_misura_operatore():
    r = mp.posiziona(_progetto(), [{'modo': 'downstream_device', 'dispositivo': 'a', 'strumento': 'MFD4421', 'rapporto': '100/5'}])
    nuova = r['measurementAssemblies'][-1]
    assert nuova['measuredFeeder'] == 'a' and nuova['ratio'] == '100/5' and nuova['status'] == 'operator_placed'


def test_progetto_originale_non_modificato():
    p = _progetto()
    mp.posiziona(p, [{'modo': 'downstream_device', 'dispositivo': 'a', 'strumento': 'MFD4421'}])
    assert len(p['measurementAssemblies']) == 1


@pytest.mark.parametrize('voce', [
    {'modo': 'upstream_general'},
    {'modo': 'downstream_general', 'dispositivo': 'a'},
    {'modo': 'downstream_device'},
    {'modo': 'downstream_device', 'dispositivo': 'zz', 'strumento': 'MFD4421'},
    {'modo': 'downstream_device', 'dispositivo': 'a'},
    {'modo': 'downstream_device', 'dispositivo': 'g', 'strumento': 'MFD4421'},
])
def test_scelte_non_valide(voce):
    with pytest.raises(ValueError):
        mp.posiziona(_progetto(), [voce])


def test_generale_non_univoco_richiede_scelta():
    p = _progetto()
    p['nodes'].append({'id': 'h', 'sigla': 'QS9', 'parent': None, 'values': {}})
    with pytest.raises(ValueError):
        mp.posiziona(p, [{'modo': 'downstream_general', 'strumento': 'MFD4421'}])


def _comp(page, article, box, family='Strumenti di misura'):
    return {'page': page, 'article': article, 'box': box, 'family': family}


def test_strumento_senza_geometria_diventa_misura_da_collocare():
    comps = [_comp(7, 'MFD4421', [339, 226, 374, 235]), _comp(7, 'F8TB100', [339, 235, 372, 244], 'Altri apparecchi'),
             _comp(9, 'F323N', [10, 10, 30, 20], 'Fusibili')]
    misure = []
    nuove = mp.misure_da_collocare(misure, comps)
    assert len(nuove) == 1 and misure == nuove
    m = nuove[0]
    assert m['status'] == 'unplaced' and m['measuredFeeder'] is None
    assert m['relatedQuotationArticles'] == ['F8TB100']
    assert all(c.get('linkedMeasurementId') == m['id'] for c in comps[:2])
    assert 'linkedMeasurementId' not in comps[2]


def test_strumento_gia_collegato_non_duplicato():
    comps = [dict(_comp(5, 'MFD41ORFCDT', [1, 1, 9, 9]), linkedMeasurementId='x')]
    assert mp.misure_da_collocare([], comps) == []


def test_misura_da_collocare_si_posiziona_con_le_scelte_operatore():
    p = _progetto()
    p['measurementAssemblies'] = [{'id': 'u1', 'status': 'unplaced', 'measuredFeeder': None, 'articleProposal': 'MFD4421'}]
    r = mp.posiziona(p, [{'misura': 'u1', 'modo': 'downstream_device', 'dispositivo': 'a'}])
    m = r['measurementAssemblies'][0]
    assert m['measuredFeeder'] == 'a' and m['assignmentSource'] == 'operator'


def test_piu_misure_non_collocate_non_sono_un_conflitto():
    p = _progetto()
    p['measurementAssemblies'] = [{'id': 'u1', 'measuredFeeder': None}, {'id': 'u2', 'measuredFeeder': None}]
    r = mp.posiziona(p, [{'misura': 'u1', 'modo': 'downstream_device', 'dispositivo': 'a'}])
    assert r['measurementAssemblies'][0]['measuredFeeder'] == 'a' and r['measurementAssemblies'][1]['measuredFeeder'] is None
