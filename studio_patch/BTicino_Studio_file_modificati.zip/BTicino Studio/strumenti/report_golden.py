"""Confronto articoli PDF input (annotazioni FreeText) <-> as-built.

Uso: python strumenti/report_golden.py
Stampa la tabella delle metriche e scrive tests/golden_baseline.json.
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
for percorso in (ROOT, ROOT / 'Alpha'):
    if str(percorso) not in sys.path:
        sys.path.insert(0, str(percorso))

import pymupdf  # noqa: E402

import listino  # noqa: E402
import pdf_annotazioni  # noqa: E402

DATASET = ROOT / 'dataset_input'
MATRICOLE = DATASET / 'matricole.json'
ASBUILT = DATASET / 'asbuilt'
BASELINE = ROOT / 'tests' / 'golden_baseline.json'

_TOKEN = re.compile(r'[A-Z0-9][A-Z0-9/\-]*[A-Z0-9]')


def carica_matricole() -> dict:
    with MATRICOLE.open(encoding='utf-8') as file:
        return json.load(file)


def trova_input(nome: str) -> Path | None:
    return next(iter(sorted(DATASET.rglob(nome))), None)


def pdf_asbuilt(matricola: str) -> list[Path]:
    cartella = ASBUILT / matricola
    return sorted(cartella.glob('*.pdf')) if cartella.is_dir() else []


def _e_articolo(token: str) -> bool:
    # Esclude sigle (F12...) non in listino e numeri brevi come '010' o '500'.
    if not listino.esiste(token):
        return False
    return bool(re.fullmatch(r'\d{6}', token) or (re.search(r'[A-Z]', token) and re.search(r'\d', token)))


def codici_asbuilt(percorsi) -> set[str]:
    codici = set()
    for percorso in percorsi:
        with pymupdf.open(str(percorso)) as doc:
            for pagina in doc:
                codici.update(t for t in _TOKEN.findall(pagina.get_text().upper()) if _e_articolo(t))
    return codici


def metrica(nome: str, matricola: str | None) -> dict:
    percorso = trova_input(nome)
    riga = {'matricola': matricola, 'input': nome, 'trovato': percorso is not None}
    codici_annot = set(pdf_annotazioni.codici(percorso)) if percorso else set()
    codici_testo = set(pdf_annotazioni.codici_da_testo_pagine(percorso)) if percorso else set()
    codici_input = codici_annot | codici_testo
    non_in_listino = sorted(c for c in codici_input if not listino.esiste(c))
    riga.update(codici_input=len(codici_input), codici_solo_testo=len(codici_testo - codici_annot), non_in_listino=non_in_listino)
    asbuilt = pdf_asbuilt(matricola) if matricola else []
    if asbuilt:
        codici_ab = codici_asbuilt(asbuilt)
        comuni = codici_input & codici_ab
        riga.update(
            asbuilt=len(codici_ab),
            comuni=len(comuni),
            percentuale=round(100 * len(comuni) / len(codici_ab), 1) if codici_ab else 0.0,
            solo_asbuilt=sorted(codici_ab - codici_input),
        )
    else:
        riga.update(asbuilt=None, comuni=None, percentuale=None, solo_asbuilt=[])
    return riga


def metriche() -> list[dict]:
    return [metrica(nome, matricola) for nome, matricola in carica_matricole().items()]


def stampa(righe: list[dict]) -> None:
    def cella(valore):
        return '-' if valore is None else str(valore)

    intestazione = ['matricola', 'input', 'cod.input', 'as-built', 'comuni', '%', 'non in listino']
    tabella = [[cella(r['matricola']), r['input'][:42], cella(r['codici_input']), cella(r['asbuilt']),
                cella(r['comuni']), cella(r['percentuale']), ', '.join(r['non_in_listino']) or '-']
               for r in righe]
    larghezze = [max(len(x) for x in colonna) for colonna in zip(intestazione, *tabella)]
    for riga in [intestazione, ['-' * n for n in larghezze], *tabella]:
        print(' | '.join(v.ljust(n) for v, n in zip(riga, larghezze)))


def main() -> int:
    righe = metriche()
    stampa(righe)
    BASELINE.parent.mkdir(parents=True, exist_ok=True)
    with BASELINE.open('w', encoding='utf-8') as file:
        json.dump(righe, file, ensure_ascii=False, indent=2)
    print(f'\nBaseline scritta in {BASELINE}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
