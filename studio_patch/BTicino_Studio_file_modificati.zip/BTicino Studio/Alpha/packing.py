"""Pack power devices and local return lanes into the twelve standard columns."""
import collections
GRID=['C','D','E','F','G','H','M','N','P','R','S','T']
def plan_pages(nodes,capacity=12):
 byid={n['id']:n for n in nodes};children=collections.defaultdict(list)
 for n in nodes:children[n.get('parent')].append(n['id'])
 # Finish each protected branch before moving to the next subgeneral.
 # This rule is generic; no reference sheet numbers or device names are used.
 order=[];depths={};seen=set()
 def visit(ident,depth):
  if ident in seen:raise ValueError('Alimentazioni cicliche o duplicate.')
  seen.add(ident);depths[ident]=depth;order.append(ident)
  for child in children[ident]:visit(child,depth+1)
 for root in children[None]:visit(root,0)
 if len(order)!=len(nodes):raise ValueError('Alimentazioni non valide per impaginazione.')
 has_explicit_shared_source=any(byid[root].get('values',{}).get('externalSupplyGroup') for root in children[None])
 first_reserved=2 if len(children[None])==1 or has_explicit_shared_source else 0
 pages=[];positions={};page={'items':[],'lanes':{},'start_column':first_reserved,'external_column':1 if first_reserved else None};column=first_reserved
 preserve_raster_sheets=bool(nodes) and all(n.get('evidence',{}).get('axisSource')=='raster_schedule_grid' for n in nodes)
 source_sheet=None
 def source_reservation(sheet):
  source_nodes=[n for n in nodes if n.get('evidence',{}).get('page')==sheet] if sheet is not None else []
  return (2,1) if any(n.get('values',{}).get('externalSupplyGroup') for n in source_nodes) else (0,None)
 for ident in order:
  this_sheet=byid[ident].get('evidence',{}).get('page') if preserve_raster_sheets else None
  if this_sheet is not None and source_sheet is not None and this_sheet!=source_sheet and page['items']:
   pages.append(page);reserved,external=source_reservation(this_sheet);page={'items':[],'lanes':{},'start_column':reserved,'external_column':external};column=reserved
  if this_sheet is not None:source_sheet=this_sheet
  span=int(byid[ident].get('drawingWidth',1))
  if not 1<=span<=capacity:raise ValueError('Larghezza del modulo non valida.')
  width=span+(1 if children[ident] else 0)
  if column+width>capacity:
   pages.append(page);reserved,external=source_reservation(this_sheet);page={'items':[],'lanes':{},'start_column':reserved,'external_column':external};column=reserved
  row={'id':ident,'column':column,'x':80+25*column,'grid':GRID[column],'span':span};page['items'].append(row)
  positions[ident]={**row,'page':len(pages)+1}
  if children[ident]:page['lanes'][ident]=80+25*(column+span)
  column+=width
 if page['items']:pages.append(page)
 grouped_pages=[]
 for i,page in enumerate(pages):
  page['number']=i+1;page['groups']=[];grouped=collections.OrderedDict()
  for item in page['items']:
   parent=byid[item['id']].get('parent')
   source_group=byid[item['id']].get('values',{}).get('externalSupplyGroup')
   key=parent if parent is not None else (('source',source_group) if source_group else ('external',item['id']))
   grouped.setdefault(key,[]).append(item)
  grouped_pages.append(grouped)
 # Keep ancestor bars visible on intervening sheets, even without a new
 # departure on that sheet. Each bar belongs to one parent, never a merged net.
 for parent,child_ids in list(children.items()):
  if parent is None or not child_ids:continue
  first=positions[parent]['page'];last=max(positions[c]['page'] for c in child_ids)
  for number in range(first,last+1):grouped_pages[number-1].setdefault(parent,[])
 for page,grouped in zip(pages,grouped_pages):
  levels=sorted({depths[key] for key in grouped if not isinstance(key,tuple)})
  ordered=sorted(grouped.items(),key=lambda entry:(-1 if isinstance(entry[0],tuple) else depths[entry[0]], entry[1][0]['column'] if entry[1] else -1))
  for key,items in ordered:
   parent=None if isinstance(key,tuple) else key
   level=(depths[parent]+1) if parent is not None else 0
   incoming_x=30 if not items or items[0]['column']==0 else items[0]['x']-12
   if parent is not None and positions[parent]['page']<page['number']:incoming_x=30
   page['groups'].append({'parent':parent,'items':items,'carry_only':not items,
      'incoming_x':incoming_x,'outgoing_x':390,'last_x':items[-1]['x'] if items else 355,
      'bus_y':257.5-11.125*level})
  page['used_columns']=sum(r.get('span',1)+(1 if r['id'] in page['lanes'] else 0) for r in page['items'])+page['start_column']
 return pages,positions,children
