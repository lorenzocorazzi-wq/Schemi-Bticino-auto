"""Read lettered continuation arrows; geometry anchors every OCR proposal."""
import csv,io,re,subprocess
import pymupdf
from PIL import Image,ImageOps
from pdf_stroke_letters import read as stroke_letter

def read_signal_arrows(page,folder,page_index,tesseract,cached_references=None):
    edges=[]
    for drawing in page.get_drawings():
        if drawing.get('dashes','[] 0') not in ['[] 0','[] 0.0','']:continue
        for item in drawing['items']:
            if item[0]=='l':
                a,b=item[1]*page.rotation_matrix,item[2]*page.rotation_matrix
                edges.append((tuple(a),tuple(b)))
    def near(a,b):return abs(a[0]-b[0])+abs(a[1]-b[1])<.3
    def attached(point,base,tip):
        return abs(point[1]-base[1])<.3 and min(base[0],tip[0])-.3<=point[0]<=max(base[0],tip[0])+.3
    bars=[(a,b) for a,b in edges if abs(a[1]-b[1])<.3 and abs(a[0]-b[0])>10]
    cached={(round(r['point'][0],1),round(r['point'][1],1),r['role']):r for r in cached_references or []}
    refs=[];seen=set()
    for a,b in edges:
        if abs(a[0]-b[0])>.2:continue
        size=abs(a[1]-b[1])
        if not 4<size<20:continue
        center=(a[0],(a[1]+b[1])/2)
        tips=[]
        for c,d in edges:
            if near(c,a):tips.append(d)
            elif near(d,a):tips.append(c)
        for tip in tips:
            if abs(tip[1]-center[1])>.3 or not .5*size<abs(tip[0]-center[0])<1.3*size:continue
            if not any((near(c,b) and near(d,tip)) or (near(d,b) and near(c,tip)) for c,d in edges):continue
            matches=[]
            for c,d in bars:
                if abs(c[0]-d[0])<2*size:continue
                left,right=sorted([c,d])
                if attached(left,center,tip):matches.append(('arrival',left))
                if attached(right,center,tip):matches.append(('departure',right))
            if len(matches)!=1:continue
            role,point=matches[0];key=(round(point[0],1),round(point[1],1))
            if key in seen:continue
            seen.add(key)
            previous=cached.get((*key,role))
            if previous:
                refs.append({**previous,'confirmed':False});continue
            # Letter sits above the arrow tip; dimensions scale with the arrow.
            x,y=tip
            # Keep the complete lower stroke of B/D. The previous crop could
            # cut that stroke and turn a B into a confidently read R.
            left=.30 if role=='arrival' else .40
            box=pymupdf.Rect(x-left*size,y-1.34*size,x+.45*size,y-.20*size)
            pix=page.get_pixmap(matrix=pymupdf.Matrix(12,12),clip=box,alpha=False)
            im=Image.frombytes('RGB',[pix.width,pix.height],pix.samples).convert('L')
            ink=ImageOps.invert(im).getbbox()
            noise=max(4,round(size*12*.14))
            if not ink or ink[3]-ink[1]<=noise:
                below=pymupdf.Rect(x-left*size,y+.20*size,x+.45*size,y+1.34*size)
                pix=page.get_pixmap(matrix=pymupdf.Matrix(12,12),clip=below,alpha=False)
                lower=Image.frombytes('RGB',[pix.width,pix.height],pix.samples).convert('L')
                lower_ink=ImageOps.invert(lower).getbbox()
                if not lower_ink or lower_ink[3]-lower_ink[1]<=noise:
                    refs.append({'signal':None,'role':role,'point':point,'box':list(box),'belowBox':list(below),'labelStatus':'blank','method':'closed triangle; both label bands blank','confirmed':False})
                continue
            if not tesseract.is_file():continue
            im=ImageOps.expand(im.crop(ink),border=24,fill=255)
            file=folder/f'signal_{page_index}_{role}_{key[0]}_{key[1]}.png';im.save(file)
            reads=[];all_reads=[];vector_letter=stroke_letter(page,box)
            for mode in [7,10]:
                run=subprocess.run([str(tesseract),str(file),'stdout','--psm',str(mode),'-c','tessedit_char_whitelist=ABCDEFGHIJKLMNOPQRSTUVWXYZ','tsv'],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0),timeout=15)
                tokens=[r for r in csv.DictReader(io.StringIO(run.stdout.decode('utf-8',errors='replace')),delimiter='\t') if r.get('text','').strip()]
                if len(tokens)==1 and re.fullmatch('[A-Z]',tokens[0]['text']):
                    all_reads.append(tokens[0]['text'])
                    if float(tokens[0]['conf'])>=70:reads.append(tokens[0]['text'])
            if len(reads)==2 and reads[0]==reads[1]:
                refs.append({'signal':reads[0],'role':role,'point':point,'box':list(box),'method':'closed triangle + agreeing tight OCR','confirmed':False})
            elif vector_letter and vector_letter in all_reads:
                refs.append({'signal':vector_letter,'role':role,'point':point,'box':list(box),'method':'closed triangle + exact CAD stroke letter + agreeing OCR','confirmed':False})
    refs.extend(_read_flag_arrows(page,edges,folder,page_index,tesseract))
    return refs


def _read_flag_arrows(page,edges,folder,page_index,tesseract):
    """Closed pentagonal flags have their letter INSIDE, unlike triangle tags.

    Require all five sides and a real conductor at base/tip. A bare letter or
    a similar symbol in a schedule can therefore never create a continuation.
    """
    def near(a,b):return abs(a[0]-b[0])+abs(a[1]-b[1])<.35
    def neighbors(p):
        return [b if near(a,p) else a for a,b in edges if near(a,p) or near(b,p)]
    output=[];seen=set()
    for a,b in edges:
        size=abs(a[1]-b[1])
        if abs(a[0]-b[0])>.2 or not 4<size<20:continue
        top,bottom=sorted((a,b),key=lambda p:p[1]);center=(a[0],(a[1]+b[1])/2)
        for shoulder in neighbors(top):
            run=shoulder[0]-top[0]
            if abs(shoulder[1]-top[1])>.2 or not size<abs(run)<5*size:continue
            opposite=(shoulder[0],bottom[1])
            if not any(near(p,opposite) for p in neighbors(bottom)):continue
            tips=[p for p in neighbors(shoulder) if abs(p[1]-center[1])<.3 and .2*size<abs(p[0]-shoulder[0])<size and (p[0]-shoulder[0])*run>0]
            for tip in tips:
                if not any(near(p,tip) for p in neighbors(opposite)):continue
                matches=[]
                for c,d in edges:
                    if abs(c[1]-d[1])>.3 or abs(c[0]-d[0])<2*size:continue
                    left,right=sorted((c,d))
                    for anchor in (center,tip):
                        if near(left,anchor):matches.append(('arrival',left))
                        if near(right,anchor):matches.append(('departure',right))
                matches=list(dict.fromkeys(matches))
                if len(matches)!=1:continue
                role,point=matches[0];key=(round(point[0],1),round(point[1],1),role)
                if key in seen:continue
                seen.add(key)
                box=pymupdf.Rect(min(top[0],shoulder[0])+.5,top[1]+.5,max(top[0],shoulder[0])-.5,bottom[1]-.5)
                native=[s['text'].strip() for block in page.get_text('dict')['blocks'] for line in block.get('lines',[]) for s in line['spans'] if re.fullmatch('[A-Z]',s['text'].strip()) and box.contains(pymupdf.Rect(s['bbox'])*page.rotation_matrix)]
                reads=[]
                if len(native)==1:reads=native*2
                elif tesseract.is_file():
                    pix=page.get_pixmap(matrix=pymupdf.Matrix(12,12),clip=box,alpha=False)
                    im=Image.frombytes('RGB',[pix.width,pix.height],pix.samples).convert('L');ink=ImageOps.invert(im).getbbox()
                    if not ink:continue
                    im=ImageOps.expand(im.crop(ink),border=24,fill=255)
                    file=folder/f'flag_{page_index}_{role}_{key[0]}.png';im.save(file)
                    for mode in (7,10):
                        run=subprocess.run([str(tesseract),str(file),'stdout','--psm',str(mode),'-c','tessedit_char_whitelist=ABCDEFGHIJKLMNOPQRSTUVWXYZ','tsv'],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0),timeout=15)
                        tokens=[r for r in csv.DictReader(io.StringIO(run.stdout.decode('utf8',errors='replace')),delimiter='\t') if r.get('text','').strip()]
                        if len(tokens)==1 and re.fullmatch('[A-Z]',tokens[0]['text']) and float(tokens[0]['conf'])>=60:reads.append(tokens[0]['text'])
                if len(reads)==2 and reads[0]==reads[1]:
                    output.append({'signal':reads[0],'role':role,'point':point,'box':list(box),'method':'closed pentagonal flag + attached conductor + agreeing label reads','confirmed':False})
    return output
