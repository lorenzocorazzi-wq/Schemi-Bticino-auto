"""Articoli BTicino scritti come annotazioni FreeText nei PDF di progetto.

Una annotazione puo' contenere piu' codici separati da a capo (es.
"FN84C63\\rG44AC63" = magnetotermico + blocco differenziale, una sola unita').
"""
from __future__ import annotations

import collections
import re
from pathlib import Path

import pymupdf

import listino

PREFISSO_SCARTO = 'EGINFO'  # metadati EPlus (EgInfo¦...)
_SEPARATORI = re.compile(r'[\r\n]+')
_CODICE = re.compile(r'[A-Z0-9][A-Z0-9/\-]*[A-Z0-9]')

# Ordine significativo: vince la prima regola che corrisponde.
_TIPI = [
    ('magnetotermico', re.compile(r'F[NHTAC]8\d')),
    ('differenziale', re.compile(r'G')),
    ('scatolato', re.compile(r'T\d')),
    ('accessorio_scatolato', re.compile(r'M7')),
    ('numerico', re.compile(r'\d+$')),
    ('spd/fusibile/accessorio', re.compile(r'F')),
]


def tipo_codice(codice: str) -> str:
    for tipo, regola in _TIPI:
        if regola.match(codice):
            return tipo
    return 'sconosciuto'


def codici_da_testo(testo: str) -> list[str]:
    """Codici normalizzati di un'annotazione: una riga per codice, spazi tolti."""
    codici = []
    for riga in _SEPARATORI.split(testo or ''):
        riga = listino.normalizza(riga)
        if len(riga) >= 3 and _CODICE.fullmatch(riga) and re.search(r'\d', riga):
            codici.append(riga)
    return codici


def _pagine(sorgente):
    if isinstance(sorgente, pymupdf.Page):
        return [sorgente], None
    if isinstance(sorgente, pymupdf.Document):
        return list(sorgente), None
    doc = pymupdf.open(str(Path(sorgente)))
    return list(doc), doc


def estrai_articoli(sorgente) -> list[dict]:
    """Accetta un percorso, un pymupdf.Document o una singola pymupdf.Page."""
    pagine, da_chiudere = _pagine(sorgente)
    articoli = []
    try:
        for pagina in pagine:
            for annot in pagina.annots(types=[pymupdf.PDF_ANNOT_FREE_TEXT]) or []:
                testo = annot.info.get('content', '') or ''
                if listino.normalizza(testo).startswith(PREFISSO_SCARTO):
                    continue
                codici = codici_da_testo(testo)
                if not codici:
                    continue
                tipi = [tipo_codice(c) for c in codici]
                articoli.append({
                    'pagina': pagina.number + 1,
                    'rect': [round(v, 2) for v in annot.rect],
                    'testo': testo,
                    'codici': codici,
                    'tipi': tipi,
                    'unita_mt_diff': 'magnetotermico' in tipi and any(re.match(r'G\d', c) for c in codici),
                    'verifiche': [listino.verifica(c) for c in codici],
                })
    finally:
        if da_chiudere is not None:
            da_chiudere.close()
    return articoli


def codici(sorgente) -> collections.Counter:
    return collections.Counter(c for articolo in estrai_articoli(sorgente) for c in articolo['codici'])


_TOKEN_TESTO = re.compile(r'[A-Z0-9][A-Z0-9/\-]*[A-Z0-9]')


def _e_articolo_testo(token: str) -> bool:
    if not listino.esiste(token):
        return False
    return bool(re.fullmatch(r'\d{6}', token) or (re.search(r'[A-Z]', token) and re.search(r'\d', token)))


def codici_da_testo_pagine(sorgente) -> collections.Counter:
    """Codici in listino scritti come testo normale della pagina (PDF senza annotazioni FreeText)."""
    pagine, da_chiudere = _pagine(sorgente)
    conteggio: collections.Counter = collections.Counter()
    try:
        for pagina in pagine:
            testo = pagina.get_text().upper()
            conteggio.update(t for t in _TOKEN_TESTO.findall(testo) if _e_articolo_testo(t))
    finally:
        if da_chiudere is not None:
            da_chiudere.close()
    return conteggio
