"""Accesso al listino BTicino locale (catalogo/listino_bticino_2126.json).

Struttura del JSON: {codice: {"d": descrizione, "p": prezzo}}.
"""
from __future__ import annotations

import json
import re
from functools import lru_cache
from pathlib import Path

PERCORSO_LISTINO = Path(__file__).resolve().parents[1] / 'catalogo' / 'listino_bticino_2126.json'
MAX_SUGGERIMENTI = 3


def normalizza(codice: str) -> str:
    return re.sub(r'\s+', '', str(codice or '')).upper()


@lru_cache(maxsize=1)
def _dati() -> dict:
    if not PERCORSO_LISTINO.is_file():
        raise FileNotFoundError(
            f'Listino BTicino non trovato: {PERCORSO_LISTINO}. '
            'Copiare listino_bticino_2126.json nella cartella catalogo del progetto.'
        )
    with PERCORSO_LISTINO.open(encoding='utf-8') as file:
        dati = json.load(file)
    if not isinstance(dati, dict):
        raise ValueError(f'Formato listino inatteso in {PERCORSO_LISTINO}: atteso un oggetto codice -> dati.')
    return {normalizza(codice): voce for codice, voce in dati.items()}


@lru_cache(maxsize=1)
def _famiglie() -> dict:
    # Indice per primo carattere: limita il confronto per distanza di edit.
    famiglie: dict[str, list[str]] = {}
    for codice in _dati():
        famiglie.setdefault(codice[:1], []).append(codice)
    return famiglie


def esiste(codice: str) -> bool:
    return normalizza(codice) in _dati()


def descrizione(codice: str) -> str | None:
    voce = _dati().get(normalizza(codice))
    if voce is None:
        return None
    return voce.get('d') if isinstance(voce, dict) else str(voce)


def distanza(a: str, b: str, limite: int | None = None) -> int:
    """Distanza di Levenshtein; interrompe oltre `limite` se indicato."""
    if len(a) < len(b):
        a, b = b, a
    precedente = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        corrente = [i]
        for j, cb in enumerate(b, 1):
            corrente.append(min(precedente[j] + 1, corrente[j - 1] + 1, precedente[j - 1] + (ca != cb)))
        if limite is not None and min(corrente) > limite:
            return limite + 1
        precedente = corrente
    return precedente[-1]


def suggerimenti(codice: str, massimo: int = MAX_SUGGERIMENTI) -> list[str]:
    codice = normalizza(codice)
    if not codice:
        return []
    limite = max(2, len(codice) // 3)
    candidati = []
    for altro in _famiglie().get(codice[:1], []):
        if altro == codice or abs(len(altro) - len(codice)) > limite:
            continue
        d = distanza(codice, altro, limite)
        if d <= limite:
            candidati.append((d, altro))
    candidati.sort()
    risultato = [altro for _, altro in candidati]
    # Prefissi non BTicino (es. 'LG-412654'): proponi la parte dopo il trattino.
    coda = codice.rsplit('-', 1)[-1]
    if coda != codice and coda in _dati():
        risultato.insert(0, coda)
    return list(dict.fromkeys(risultato))[:massimo]


def verifica(codice: str) -> dict:
    codice = normalizza(codice)
    trovato = esiste(codice)
    return {
        'codice': codice,
        'esiste': trovato,
        'descrizione': descrizione(codice) if trovato else None,
        'suggerimenti': [] if trovato else suggerimenti(codice),
    }


# Coppie di caratteri che l'OCR scambia spesso (lette in entrambe le direzioni).
_CONFUSIONI = ('01', '0O', '0D', '1I', '1L', '1T', '1A', '25', '2Z', '35', '3S', '4A', '5S', '6G', '8B', '8S')


@lru_cache(maxsize=1)
def _scambi() -> dict:
    scambi: dict[str, set[str]] = {}
    for a, b in _CONFUSIONI:
        scambi.setdefault(a, set()).add(b)
        scambi.setdefault(b, set()).add(a)
    return scambi


def correggi_ocr(codice: str) -> str | None:
    """Unico codice di listino raggiungibile scambiando UN carattere confuso dall'OCR.

    Restituisce None se il codice e' gia' valido, se non c'e' nessuna correzione
    o se ce ne sono piu' di una (ambiguo: lo decide l'operatore).
    """
    codice = normalizza(codice)
    if not codice or esiste(codice):
        return None
    scambi = _scambi()
    candidati = set()
    for i, carattere in enumerate(codice):
        for altro in scambi.get(carattere, ()):
            variante = codice[:i] + altro + codice[i + 1:]
            if esiste(variante):
                candidati.add(variante)
    return candidati.pop() if len(candidati) == 1 else None
