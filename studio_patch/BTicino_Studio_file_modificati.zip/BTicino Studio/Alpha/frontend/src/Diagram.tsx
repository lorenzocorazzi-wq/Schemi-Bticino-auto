import { useRef, useState, useMemo, useEffect } from 'react';
import type { PointerEvent } from 'react';
import { Button } from 'antd';
import { orthogonalBranches, layoutHierarchy } from './hierarchy';
import type { LayoutNode } from './hierarchy';
import type { Device, MeasurementAssembly } from './types';
const METER_BAND = 52;
type Props = {
    nodes: LayoutNode<Device>[];
    selected: string | null;
    onSelect: (id: string | null) => void;
    onMove: (id: string, dx: number, dy: number) => void;
    onConnect: (child: string, parent: string) => void;
    onImport: () => void;
    disabled: boolean;
    measurements?: MeasurementAssembly[];
    selectedMeasurement?: string | null;
    onSelectMeasurement?: (id: string) => void;
    onMoveMeasurement?: (id: string, deviceId: string) => void;
};
export function Diagram({ nodes, selected, onSelect, onMove, onConnect, onImport, disabled, measurements = [], selectedMeasurement = null, onSelectMeasurement, onMoveMeasurement }: Props) {
    const viewport = useRef<HTMLDivElement>(null), world = useRef<HTMLDivElement>(null);
    const [viewportWidth, setViewportWidth] = useState(800);
    useEffect(() => {
        if (!viewport.current) return;
        const observer = new ResizeObserver(entries => setViewportWidth(entries[0].contentRect.width));
        observer.observe(viewport.current);
        return () => observer.disconnect();
    }, []);
    const [zoom, setZoom] = useState(1), [drag, setDrag] = useState<{
        id: string;
        px: number;
        py: number;
        dx: number;
        dy: number;
    } | null>(null), [hover, setHover] = useState<string | null>(null), [link, setLink] = useState<string | null>(null);
    const portDrag = useRef<{
        id: string;
        pointerId: number;
    } | null>(null);
    useEffect(() => {
        function finishPort(e: globalThis.PointerEvent) {
            const source = portDrag.current;
            if (!source || source.pointerId !== e.pointerId)
                return;
            portDrag.current = null;
            const input = document.elementFromPoint(e.clientX, e.clientY)?.closest<HTMLElement>('[data-input]');
            const child = input?.dataset.input;
            if (child && child !== source.id) {
                setLink(null);
                onConnect(child, source.id);
            }
        }
        function cancelPort() { portDrag.current = null; setLink(null); setDrag(null); setHover(null); }
        document.addEventListener('pointerup', finishPort);
        document.addEventListener('pointercancel', cancelPort);
        window.addEventListener('blur', cancelPort);
        return () => { document.removeEventListener('pointerup', finishPort); document.removeEventListener('pointercancel', cancelPort); window.removeEventListener('blur', cancelPort); };
    }, [onConnect]);
    const descendants = (id: string) => { const ids = new Set([id]); let changed = true; while (changed) {
        changed = false;
        for (const n of nodes)
            if (n.parent && ids.has(n.parent) && !ids.has(n.id)) {
                ids.add(n.id);
                changed = true;
            }
    } return ids; };
    const moved = drag ? descendants(drag.id) : new Set<string>();
    const ids = useMemo(() => new Set(nodes.map(n => n.id)), [nodes]);
    const placedMeasurements = useMemo(() => measurements.filter(m => m.measuredFeeder && ids.has(m.measuredFeeder)), [measurements, ids]);
    const extraBelow = useMemo(() => new Map(placedMeasurements.map(m => [m.measuredFeeder as string, METER_BAND])), [placedMeasurements]);
    const [meterDrag, setMeterDrag] = useState<{ id: string; px: number; py: number; dx: number; dy: number } | null>(null);
    // Le coordinate salvate sono relative alla disposizione senza misure: lo spazio riservato resta fuori dalla linea di base.
    const baseline = useMemo(() => new Map(layoutHierarchy(nodes).map(n => [n.id, n])), [nodes]);
    const responsive = useMemo(() => layoutHierarchy(nodes, viewportWidth / zoom, extraBelow), [nodes, viewportWidth, zoom, extraBelow]);
    const drawn = responsive.map(n => {
        const saved = nodes.find(item => item.id === n.id)!;
        const base = baseline.get(n.id)!;
        return { ...n, x: n.x + saved.x - base.x + (drag && moved.has(n.id) ? drag.dx : 0), y: n.y + saved.y - base.y + (drag && moved.has(n.id) ? drag.dy : 0) };
    });
    const branches = useMemo(() => orthogonalBranches(drawn), [drawn]);
    const width = Math.max(420, ...drawn.map(n => n.x + n.width + 20)), height = Math.max(400, ...drawn.map(n => n.y + n.height + 100));
    function fit() { if (!viewport.current)
        return; const v = viewport.current; setZoom(1); const anchor = drawn.find(n => n.id === selected) || drawn[0]; v.scrollLeft = anchor ? Math.max(0, anchor.x + anchor.width / 2 - v.clientWidth / 2) : 0; v.scrollTop = anchor ? Math.max(0, anchor.y - 20) : 0; }
    useEffect(() => { fit(); }, [nodes.length]);
    function targetAt(e: PointerEvent) { return document.elementsFromPoint(e.clientX, e.clientY).map(el => el.closest<HTMLElement>('[data-device]')).find(el => el && !moved.has(el.dataset.device!))?.dataset.device || null; }
    function releaseMeter(e: PointerEvent) {
        if (!meterDrag) return;
        const dx = (e.clientX - meterDrag.px) / zoom, dy = (e.clientY - meterDrag.py) / zoom;
        const moved = Math.abs(dx) + Math.abs(dy) > 3;
        const candidate = moved ? targetAt(e) : null;
        const id = meterDrag.id;
        setMeterDrag(null); setHover(null);
        if (candidate) onMoveMeasurement?.(id, candidate);
        else if (!moved) onSelectMeasurement?.(id);
    }
    function release(e: PointerEvent) { if (!drag)
        return; const dx = (e.clientX - drag.px) / zoom, dy = (e.clientY - drag.py) / zoom; const didMove = Math.abs(dx) + Math.abs(dy) > 3; const candidate = didMove ? targetAt(e) : null; setDrag(null); setHover(null); if (candidate)
        onConnect(drag.id, candidate);
    else if (didMove)
        onMove(drag.id, dx, dy);
    else
        onSelect(drag.id); }
    return <section className="diagram"><div className="diagram-tools"><span className="diagram-summary"><strong>{nodes.length} apparecchi</strong><span>{nodes.filter(n => n.parent).length} collegamenti · trascina per organizzare</span>{link ? ' · scegli l’ingresso del blocco a valle' : ''}</span><div><Button size="small" onClick={() => setZoom(z => Math.max(.12, z / 1.2))} aria-label="Riduci zoom">−</Button><span>{Math.round(zoom * 100)}%</span><Button size="small" onClick={() => setZoom(z => Math.min(2, z * 1.2))} aria-label="Aumenta zoom">+</Button><Button size="small" onClick={fit}>Centra</Button>{link && <Button size="small" onClick={() => setLink(null)}>Annulla filo</Button>}</div></div>
 <div className="viewport" ref={viewport} onClick={e => { if (e.target === e.currentTarget)
        onSelect(null); }} onWheel={e => { if (e.ctrlKey)
        setZoom(z => Math.max(.12, Math.min(2, z * (e.deltaY < 0 ? 1.08 : .92)))); }}>
 {nodes.length === 0 ? <div className="empty-diagram"><span className="eyebrow">01 / DOCUMENTO</span><h1>Dal PDF al tuo schema.</h1><p>Importa il progetto. Verifica i blocchi riconosciuti e trascinali per organizzare le alimentazioni.</p><Button type="primary" onClick={onImport} disabled={disabled}>Importa PDF</Button></div> : <div style={{ width: width * zoom, height: height * zoom }}><div ref={world} className="diagram-world" style={{ width, height, transform: `scale(${zoom})` }}>
 <svg className="connections" width={width} height={height}>{branches.map(b => <path key={b.childId} data-branch={b.childId} d={b.path} className={b.childId === selected || b.parentId === selected ? 'active' : ''}/>)}</svg>
 {drawn.map(n => <div key={n.id} data-device={n.id} className={'device' + (!n.parent ? ' supply-device' : '') + (selected === n.id ? ' selected' : '') + (hover === n.id ? ' drop-target' : '') + (n.layoutIssue ? ' invalid' : '')} style={{ left: n.x, top: n.y, width: n.width, height: n.height, fontSize: 14 }} onPointerDown={e => { if (disabled || e.button !== 0 || e.target instanceof Element && e.target.closest('button'))
                return; e.preventDefault(); setDrag({ id: n.id, px: e.clientX, py: e.clientY, dx: 0, dy: 0 }); e.currentTarget.setPointerCapture(e.pointerId); }} onPointerMove={e => { if (!drag || drag.id !== n.id)
                return; const dx = (e.clientX - drag.px) / zoom, dy = (e.clientY - drag.py) / zoom; setDrag({ ...drag, dx, dy }); setHover(targetAt(e)); }} onPointerUp={release} onPointerCancel={() => { setDrag(null); setHover(null); }}>
 <button className="socket in" data-input={n.id} disabled={disabled} aria-label={`Ingresso ${n.sigla}`} onClick={e => { e.stopPropagation(); if (link && link !== n.id) {
                onConnect(n.id, link);
                setLink(null);
            } }}/><div className="device-head"><b>{n.sigla} · {n.kind}</b><span title={n.confirmed && n.connectionConfirmed ? 'Confermato' : 'Da verificare'}>{n.confirmed && n.connectionConfirmed ? '✓' : '○'}</span></div><div className="device-label" style={{ fontSize: 14 }} title={n.label}>{n.label}</div><small style={{ fontSize: 12 }} title={(n.articles || []).join(' + ') || n.values.articolo}>{(n.articles || []).join(' + ') || n.values.articolo || 'Articolo da verificare'}</small><small className="device-plate" title={[n.values.taratura,n.values.curva_Im,n.values.potere_interruzione,n.values.differenziale].filter(Boolean).join(' · ')}>{[n.values.taratura,n.values.curva_Im,n.values.potere_interruzione].filter(Boolean).join(' · ') || 'Dati di targa da verificare'}</small>{n.layoutIssue && <small style={{ fontSize: 12 }}>Alimentazione non valida</small>}<button className={'socket out' + (link === n.id ? ' armed' : '')} disabled={disabled} aria-label={`Uscita ${n.sigla}`} onClick={e => { e.stopPropagation(); if (e.detail === 0)
                setLink(n.id); }} onPointerDown={e => { e.stopPropagation(); if (disabled || e.button !== 0)
                return; portDrag.current = { id: n.id, pointerId: e.pointerId }; setLink(n.id); }}/>
 </div>)}
 {placedMeasurements.map(m => {
            const device = drawn.find(n => n.id === m.measuredFeeder)!;
            const dragged = meterDrag && meterDrag.id === m.id;
            const label = `MU · ${m.articleProposal || 'strumento'}`;
            const detail = [m.ratio ? `TA ${m.ratio}` : 'TA da definire', m.quantity ? `×${m.quantity}` : ''].filter(Boolean).join(' ');
            const left = device.x + 16, top = device.y + device.height + 8;
            return <div key={m.id}><div className="meter-link" style={{ left: left + 18, top: device.y + device.height, height: 8 }}/>
 <div data-measurement={m.id} className={'meter' + (selectedMeasurement === m.id ? ' selected' : '') + (dragged ? ' drop-source' : '')} style={{ left, top, width: Math.max(220, device.width - 32), height: METER_BAND - 14, transform: dragged ? `translate(${meterDrag!.dx}px, ${meterDrag!.dy}px)` : undefined }}
 onPointerDown={e => { if (disabled || e.button !== 0) return; e.preventDefault(); setMeterDrag({ id: m.id, px: e.clientX, py: e.clientY, dx: 0, dy: 0 }); e.currentTarget.setPointerCapture(e.pointerId); }}
 onPointerMove={e => { if (!meterDrag || meterDrag.id !== m.id) return; setMeterDrag({ ...meterDrag, dx: (e.clientX - meterDrag.px) / zoom, dy: (e.clientY - meterDrag.py) / zoom }); setHover(targetAt(e)); }}
 onPointerUp={releaseMeter} onPointerCancel={() => { setMeterDrag(null); setHover(null); }}>
 <span className="ta-chip" title="Trascina il TA su un altro blocco per misurare quell’utenza"><i/><i/> TA</span>
 <b>{label}</b><span className="meter-text">{detail}{m.measuredFeederConfirmed ? '' : ' · da confermare'}</span></div></div>;
        })}
 </div></div>}
 </div><footer className="diagram-hint">Trascina un blocco sul padre per inserirlo a valle. Trascina il TA di un multimetro su un altro blocco per spostare la misura. Le linee rappresentano le alimentazioni del disegno.</footer></section>;
}




