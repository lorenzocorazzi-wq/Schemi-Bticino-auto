import { CableTypeReview } from './CableTypeReview';
import { ReviewWizard } from './ReviewWizard';
import { useEffect, useRef, useState } from 'react';
import { Alert, Button, Checkbox, Collapse, ConfigProvider, Drawer, Dropdown, Empty, Input, InputNumber, Modal, Progress, Select, Space } from 'antd';
import { api, encodeFile, importPdf } from './api';
import { Diagram } from './Diagram';
import { MeasurementPanel } from './MeasurementPanel';
import { editProjectDevice } from './editDevice';
import { Inspector, TextEdit } from './Inspector';
import { Scan } from './Scan';
import { LiveDrawing } from './LiveDrawing';
import { PdfReview } from './PdfReview';
import MhqUpload from './MhqUpload';
import DrawingData from './DrawingData';
import { layoutHierarchy, reparentNode, validateConnection } from './hierarchy';
import type { LayoutNode } from './hierarchy';
import { useMemory } from './memory';
import { DRAFT_KEY, emptyProject, unresolved } from './types';
import type { Project, Device, Bootstrap, Correction, ExportResult } from './types';
const clone = <T,>(v: T): T => structuredClone(v);
function prepare(p: Project): Project { if (!p || !Array.isArray(p.nodes))
    throw Error('Progetto non valido'); const normalized = { ...emptyProject(), ...p, settings: { ...emptyProject().settings, ...p.settings }, nodes: p.nodes.map(n => ({ ...n, values: n.values || {} })) }; return { ...normalized, nodes: p.diagramLayoutVersion === 3 && normalized.nodes.every(n => Number.isFinite(n.x) && Number.isFinite(n.y) && n.width && n.height) ? normalized.nodes : layoutHierarchy(normalized.nodes), diagramLayoutVersion: 3 }; }
function changed(before: unknown, after: unknown) { return JSON.stringify(before) !== JSON.stringify(after); }
function corrections(before: Project, after: Project, source: string): Correction[] { const out: Correction[] = []; const push = (n: Device | undefined, field: string, a: unknown, b: unknown) => { if (!changed(a ?? '', b ?? ''))
    return; out.push({ correctionId: crypto.randomUUID(), sourceProject: before.name, sourcePdf: before.sourcePdf || '', nodeId: n?.id || 'project', sigla: n?.sigla || '', article: n?.values.articolo || '', page: n?.evidence?.page, field, before: a ?? '', after: b ?? '', evidence: { source, axis: n?.evidence?.axis, articleBox: n?.evidence?.articleBox } }); }; for (const n of after.nodes) {
    const old = before.nodes.find(x => x.id === n.id);
    if (!old) {
        push(n, 'device_added', '', n);
        continue;
    }
    push(old, 'parent', old.parent, n.parent);
    push(old, 'sigla', old.sigla, n.sigla);
    push(old, 'kind', old.kind, n.kind);
    push(old, 'utenza', old.label, n.label);
    for (const k of new Set([...Object.keys(old.values), ...Object.keys(n.values)]))
        push(old, k, old.values[k], n.values[k]);
    for (const k of ['confirmed', 'connectionConfirmed'])
        push(old, k, old[k], n[k]);
    if (source === 'diagram_drag')
        push(old, 'layout_position', { x: old.x, y: old.y }, { x: n.x, y: n.y });
} for (const n of before.nodes)
    if (!after.nodes.some(x => x.id === n.id))
        push(n, 'device_removed', n, ''); push(undefined, 'settings', before.settings, after.settings); push(undefined, 'project_name', before.name, after.name); push(undefined, 'matricola', before.matricola, after.matricola); push(undefined, 'odl', before.odl, after.odl); for (const k of ['operatorNotes', 'boardRequirements', 'mhq', 'hasMhq', 'board', 'documentInfo'])
    push(undefined, k, before[k], after[k]); return out; }
async function saveInBrowser(project: unknown, name: string): Promise<string> {
    const text = JSON.stringify(project, null, 2);
    const picker = (window as any).showSaveFilePicker;
    if (picker) {
        try {
            const handle = await picker({ suggestedName: name, id: 'bticino-progetti', startIn: 'documents', types: [{ description: 'Progetto BTicino Studio', accept: { 'application/json': ['.json'] } }] });
            const writable = await handle.createWritable();
            await writable.write(text);
            await writable.close();
            return 'Progetto salvato in ' + handle.name;
        }
        catch (e) {
            if (e instanceof DOMException && e.name === 'AbortError')
                return 'Salvataggio con nome annullato: resta solo la copia di lavoro interna.';
        }
    }
    const url = URL.createObjectURL(new Blob([text], { type: 'application/json' }));
    const link = document.createElement('a');
    link.href = url;
    link.download = name;
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 5000);
    return 'Progetto scaricato come ' + name + '.';
}
export default function Studio() {
    const [project, setProject] = useState<Project>(emptyProject), [ready, setReady] = useState(false), [selected, setSelected] = useState<string | null>(null), [notice, setNotice] = useState(''), [drawer, setDrawer] = useState<string | null>(null), [busy, setBusy] = useState<{
        message: string;
        live?: boolean;
        percent?: number;
        importing?: boolean;
    } | null>(null), [pendingLink, setPendingLink] = useState<{
        child: string;
        parent: string | null;
    } | null>(null), [clearOpen, setClearOpen] = useState(false), [removeId, setRemoveId] = useState<string | null>(null), [files, setFiles] = useState<string[] | null>(null), [result, setResult] = useState<(ExportResult & {
        draft: boolean;
    }) | null>(null), [memory, setMemory] = useState<any>(null), [history, setHistory] = useState<Project[]>([]), [savedId, setSavedId] = useState<string | null>(null);
    const [reviewProject, setReviewProject] = useState<Project | null>(() => { try {
        const raw = localStorage.getItem('bticino-review-stage-v1');
        return raw ? JSON.parse(raw) : null;
    }
    catch {
        return null;
    } }), [liveProject, setLiveProject] = useState<Project | null>(null), [reviewOpen, setReviewOpen] = useState(true);
    const file = useRef<HTMLInputElement>(null), current = useRef(project), abort = useRef<AbortController | null>(null), generation = useRef(0);
    current.current = project;
    const learning = useMemory();
 const [cableReviewOpen,setCableReviewOpen]=useState(false);
 const [drawingData,setDrawingData]=useState<'draft'|'export'|'edit'|null>(null);
 const [measurePanel,setMeasurePanel]=useState<{id:string|null;deviceId?:string|null}|null>(null);
    const [request, setRequest] = useState({ kind: 'MTD', poles: '4P', current: 25, voltage: 400, curve: 'C', diff_mA: 30, diff_type: 'A', label: 'Nuova utenza' });
    useEffect(() => {
        let active = true;
        let local: Project | null = null;
        const raw = localStorage.getItem(DRAFT_KEY);
        if (raw) { try { local = prepare(JSON.parse(raw)); setProject(local); setReady(true); } catch { setNotice('Bozza locale non leggibile: conservata senza sovrascriverla.'); } }
        api<Bootstrap>('/api/bootstrap').then(b => {
            if (!active || local || raw) return;
            setProject(prepare(b.lastImport || emptyProject())); setReady(true);
        }).catch(e => { if (active) setNotice('Motore non disponibile: ' + e.message); });
        return () => { active = false; };
    }, []);    useEffect(() => { if (!ready)
        return; try {
        localStorage.setItem(DRAFT_KEY, JSON.stringify(project));
    }
    catch (e) {
        setNotice('Bozza non salvata sul dispositivo. Usa Salva progetto: ' + String(e));
    } }, [project, ready]);
    useEffect(() => { if (!ready)
        return; try {
        if (reviewProject)
            localStorage.setItem('bticino-review-stage-v1', JSON.stringify(reviewProject));
        else
            localStorage.removeItem('bticino-review-stage-v1');
    }
    catch (e) {
        setNotice('Revisione PDF non salvata localmente: ' + String(e));
    } }, [reviewProject, ready]);
    function stageChange(next: Project) { if (!reviewProject)
        return; try {
        learning.enqueue(corrections(reviewProject, next, 'pdf_review'));
        setReviewProject(next);
    }
    catch (e) {
        setNotice('Correzione non registrata: ' + String(e));
    } }
    function commit(next: Project, source: string) { try {
        learning.enqueue(corrections(current.current, next, source));
        setHistory(h => [...h.slice(-39), clone(current.current)]);
        setProject(next);
        return true;
    }
    catch (e) {
        setNotice('Modifica non applicata: impossibile registrare la correzione. ' + String(e));
        return false;
    } }
    async function moveMeasurement(id: string, deviceId: string) {
        const roots = project.nodes.filter(n => !n.parent);
        const mode = roots.length === 1 && roots[0].id === deviceId ? 'downstream_general' : 'downstream_device';
        try {
            const result = await api<{ project: Project }>('/api/measurement/place', { project, placements: [{ misura: id, modo: mode, dispositivo: deviceId }] });
            commit(result.project, 'measurement_move');
        } catch (e) {
            setNotice('Misura non spostata: ' + (e instanceof Error ? e.message : String(e)));
        }
    }
    function undo() { const previous = history.at(-1); if (!previous)
        return; try {
        learning.enqueue(corrections(current.current, previous, 'undo_operator'));
        setProject(previous);
        setHistory(h => h.slice(0, -1));
        setSelected(null);
    }
    catch (e) {
        setNotice(String(e));
    } }
    function askConnection(child: string, parent: string | null) { const check = validateConnection(project.nodes, child, parent); if (!check.valid) {
        setNotice(check.reason || 'Collegamento non valido');
        return;
    } const existing = project.nodes.find(n => n.id === child);
    if (existing?.parent === parent && !unresolved(existing))
        return; setPendingLink({ child, parent }); }
    function connect() { if (!pendingLink)
        return; try {
        const nodes = layoutHierarchy(reparentNode(project.nodes, pendingLink.child, pendingLink.parent));
        commit({ ...project, nodes }, 'diagram_connection');
        setPendingLink(null);
    }
    catch (e) {
        setNotice(String(e));
    } }
    function move(id: string, dx: number, dy: number) { const next = clone(project), n = next.nodes.find(n => n.id === id)!; const parent = next.nodes.find(x => x.id === n.parent); dy = Math.max(dy, (parent ? (parent.y || 0) + (parent.height || 132) + 60 : 12) - (n.y || 0)); const descendants = new Set([id]); let more = true; while (more) {
        more = false;
        for (const c of next.nodes)
            if (c.parent && descendants.has(c.parent) && !descendants.has(c.id)) {
                descendants.add(c.id);
                more = true;
            }
    } for (const c of next.nodes)
        if (descendants.has(c.id)) {
            c.x = (c.x || 0) + dx;
            c.y = (c.y || 0) + dy;
        } commit(next, 'diagram_drag'); }
    function edit(key: string, value: any) { if (!selected)
        return; try {
        commit(editProjectDevice(project, selected, key, value), 'inspector_operator');
    }
    catch (e) {
        setNotice(String(e));
    } }
    async function loadPdf(input: File) { const ticket = ++generation.current; const controller = new AbortController(); abort.current = controller; setLiveProject(null); setReviewOpen(true); setBusy({ message: 'Acquisizione PDF…', importing: true, percent: 0 }); try {
        const encoded = await encodeFile(input);
        if (controller.signal.aborted)
            return;
        const r = await importPdf({ base64: encoded, name: input.name, settings: project.settings, matricola: project.matricola || '' }, s => { setBusy({ message: s.message, percent: s.percent, importing: true }); if (s.previewPages)
            setLiveProject({ ...emptyProject(), sourcePdf: s.sourcePdf, scanPreview: s.previewPages }); }, controller.signal);
        if (ticket !== generation.current)
            return;
        setReviewProject(r.project);
        setCableReviewOpen(true);
        setReviewOpen(true);
        setNotice('Rivedi i rilevamenti sul PDF, poi crea il diagramma.');
    }
    catch (e) {
        if (!(e instanceof DOMException && e.name === 'AbortError'))
            setNotice(e instanceof Error ? e.message : String(e));
    }
    finally {
        if (ticket === generation.current)
            setBusy(null);
        abort.current = null;
    } }
    const liveDone = useRef<(() => void) | null>(null);
    async function exportDrawing(draft: boolean, drawingProject: Project = project) { const shown = new Promise<void>(resolve => { liveDone.current = resolve; }); setBusy({ message: draft ? 'Generazione della bozza PDF e DWG…' : 'Verifica e generazione DWG…', live: true }); try {
        const r = await api<ExportResult>(draft ? '/api/preview' : '/api/export', { project: drawingProject });
        await Promise.race([shown, new Promise(resolve => setTimeout(resolve, 8000))]);
        setResult({ ...r, draft });
    }
    catch (e) {
        setNotice('Disegno non generato: ' + (e instanceof Error ? e.message : String(e)));
    }
    finally {
        setBusy(null);
    } }
    async function save() { try {
        const r = await api<{
            id: string;
            savedPath?: string;
            cancelled?: boolean;
            dialogUnavailable?: string;
            suggestedName?: string;
        }>('/api/save', { project, id: savedId, askLocation: true });
        setSavedId(r.id);
        if (r.savedPath)
            setNotice('Progetto salvato in ' + r.savedPath);
        else if (r.cancelled)
            setNotice('Salvataggio con nome annullato: resta solo la copia di lavoro interna.');
        else
            setNotice(await saveInBrowser(project, r.suggestedName || 'Progetto.json'));
    }
    catch (e) {
        setNotice(String(e));
    } }
    async function more(key: string) { try {
        if (key === 'drawingData') setDrawingData('edit');
        if (key === 'save')
            await save();
        if (key === 'open')
            setFiles((await api<Bootstrap>('/api/bootstrap')).projects);
        if (key === 'settings' || key === 'scan' || key === 'add' || key === 'review')
            setDrawer(key);
        if (key === 'memory') {
            setMemory(await api('/api/learning'));
            setDrawer('memory');
        }
        if (key === 'legacy') {
            localStorage.setItem(DRAFT_KEY, JSON.stringify(project));
            location.assign('/legacy.html');
        }
        if (key === 'arrange')
            commit({ ...project, nodes: layoutHierarchy(project.nodes) }, 'diagram_arrange');
    }
    catch (e) {
        setNotice(String(e));
    } }
    async function add() { setBusy({ message: 'Ricerca nel catalogo…' }); try {
        const c = request.kind === 'QS' ? { kind: 'QS', articles: [], values: { taratura: `${request.poles}/${request.current}A`, utenza: request.label }, warnings: ['Specificare articolo e coordinamento.'] } : (await api<any>('/api/select', { request, settings: project.settings })).chosen;
        let serial = project.nodes.length + 1;
        const prefix = request.kind === 'QS' ? 'QS' : 'QF';
        while (project.nodes.some(n => n.sigla === prefix + serial))
            serial++;
        const id = crypto.randomUUID();
        const node: Device = { ...c, id, sigla: prefix + serial, label: request.label, parent: selected, confirmed: false, connectionConfirmed: false, connectionStatus: selected ? 'scelta_operatore' : 'da_definire', request };
        if (commit({ ...project, nodes: layoutHierarchy([...project.nodes, node]) }, 'manual_device')) {
            setSelected(id);
            setDrawer(null);
        }
    }
    catch (e) {
        setNotice(String(e));
    }
    finally {
        setBusy(null);
    } }
    function clear() { generation.current++; abort.current?.abort(); if (commit(emptyProject(), 'clear_project')) {
        setSelected(null);
        setSavedId(null);
        setHistory([]);
        setDrawer(null);
        setResult(null);
        setReviewProject(null);
        setLiveProject(null);
        setReviewOpen(false);
        setClearOpen(false);
        setNotice('Progetto svuotato. Puoi importare un nuovo PDF.');
        if (file.current)
            file.current.value = '';
    } }
    async function applySettings(key: string, value: any) { const next = clone(project); next.settings = { ...next.settings, [key]: value }; if (next.boardRequirements)
        next.boardRequirements.confirmed = false; setBusy({ message: 'Aggiornamento delle proposte dal catalogo…' }); try {
        for (const n of next.nodes) {
            n.confirmed = false;
            if (n.request && n.request.kind !== 'QS' && !n.imported && !n.evidence?.articleBox) {
                try {
                    const req: Record<string, any> = { ...n.request, label: n.label };
                    const voltage = String(n.values.tensione || '').match(/^(230|400)\s*V?$/i);
                    if (voltage)
                        req.voltage = Number(voltage[1]);
                    const choice = (await api<any>('/api/select', { request: req, settings: next.settings })).chosen;
                    const old = n.values, keep: Record<string, any> = {};
                    const keys = n.imported ? ['taratura', 'curva_Im', 'differenziale', 'tensione', 'tipo_cavo', 'composizione_cavo', 'lunghezza_m', 'project_pdi_kA', 'utenza', 'fase'] : ['tipo_cavo', 'composizione_cavo', 'lunghezza_m', 'utenza', 'fase'];
                    for (const k of [...keys, 'conductors', 'conductorSpec'])
                        if (k in old)
                            keep[k] = old[k];
                    Object.assign(n, choice, { values: { ...choice.values, ...keep }, confirmed: false, selectionError: !!choice.requiresTechnicalReview });
                }
                catch (e) {
                    n.selectionError = true;
                    n.warnings = [String(e)];
                }
            }
        }
        commit(next, 'board_settings');
    }
    finally {
        setBusy(null);
    } }
    const node = project.nodes.find(n => n.id === selected), pending = project.nodes.filter(n => !n.confirmed || !n.connectionConfirmed).length, ambiguities = project.nodes.reduce((a, n) => a + Object.values(n.fieldReview || {}).filter(r => r.status === 'ambiguous').length, 0);
    return <ConfigProvider theme={{ token: { colorPrimary: '#111111', colorBgContainer: '#f5f4ef', colorText: '#111111', borderRadius: 0, fontFamily: '"Arial Narrow", "Segoe UI", sans-serif' }, components: { Button: { primaryShadow: 'none' }, Drawer: { colorBgElevated: '#f5f4ef' } } }}><div className="studio">
 <header className="studio-header"><div className="brand">BTicino Studio <span>ALPHA 0.3</span></div><nav><Button onClick={() => file.current?.click()} disabled={!!busy || !ready}>Importa PDF</Button><Button disabled={!project.nodes.length || !!busy} onClick={() => setDrawingData('draft')}>Bozza PDF</Button><Button type="primary" disabled={!project.nodes.length || !!busy} onClick={() => setDrawingData('export')}>Genera DWG</Button><Dropdown menu={{ onClick: ({ key }) => void more(key), items: [{ key: 'save', label: 'Salva progetto' }, { key: 'open', label: 'Apri progetto salvato' }, { type: 'divider' }, { key: 'drawingData', label: 'Dati del quadro e cartigli' }, { key: 'settings', label: 'Impostazioni quadro e MHQ' }, { key: 'memory', label: 'Memoria di apprendimento' }, { key: 'legacy', label: 'Editor precedente · verifiche specialistiche' }] }} trigger={['click']} disabled={!!busy}><Button>Altro</Button></Dropdown></nav></header>
 <input type="file" ref={file} accept=".pdf" hidden onChange={e => { const f = e.target.files?.[0]; e.target.value = ''; if (f)
        void loadPdf(f); }}/>
 <div className="project-bar"><div><span className="eyebrow">SCHEMA / ALIMENTAZIONI</span><h2>{project.name}</h2><span className="muted">{pending} schede da verificare{ambiguities ? ` · ${ambiguities} letture ambigue` : ''}{learning.pending ? ` · ${learning.pending} correzioni da sincronizzare` : ''}</span></div><Space wrap>{ambiguities > 0 && <Button type="primary" onClick={() => setDrawer('guided')}>Rivedi {ambiguities} letture</Button>}<Button onClick={() => setDrawer('scan')}>Documento</Button><Button onClick={() => setDrawer('add')} disabled={!!busy}>+ Apparecchio</Button><Button onClick={() => setMeasurePanel({id:null})} disabled={!!busy||!project.nodes.length}>+ Multimetro e TA</Button><Dropdown trigger={['click']} menu={{ items: [{ key: 'arrange', label: 'Riordina gerarchia' }, { key: 'undo', label: 'Annulla modifica', disabled: !history.length }, { key: 'review', label: 'Controlli del progetto' }], onClick: ({ key }) => key === 'undo' ? undo() : void more(key) }} disabled={!!busy}><Button>Modifica</Button></Dropdown><Button danger onClick={() => setClearOpen(true)} disabled={!!busy}>Svuota</Button></Space></div>
 {notice && <Alert className="notice" title={notice} closable onClose={() => setNotice('')} type="info"/>}{learning.error && <Alert title={`Memoria non sincronizzata: ${learning.error}. Le correzioni restano nella coda locale.`} type="warning" action={<Button onClick={() => void learning.retry()}>Riprova</Button>}/>}
 {reviewProject && !reviewOpen && <Alert title='Revisione PDF in attesa' action={<Button onClick={() => setReviewOpen(true)}>Riprendi revisione</Button>}/>}
 {drawingData && <DrawingData project={project} onClose={()=>setDrawingData(null)} onApply={next=>{if(commit(next,'drawing_metadata')){const mode=drawingData;setDrawingData(null);if(mode!=='edit')void exportDrawing(mode==='draft',next);}}}/>}{drawer === 'guided' && <ReviewWizard project={project} onClose={() => setDrawer(null)} onChange={p => { commit(p, 'guided_review'); }} onDraft={() => { setDrawer(null); setDrawingData('draft'); }}/>}<Diagram nodes={project.nodes as LayoutNode<Device>[]} selected={selected} onSelect={setSelected} onMove={move} onConnect={askConnection} onImport={() => file.current?.click()} disabled={!!busy || !ready} measurements={project.measurementAssemblies||[]} selectedMeasurement={measurePanel?.id??null} onSelectMeasurement={id=>setMeasurePanel({id})} onMoveMeasurement={(id,deviceId)=>void moveMeasurement(id,deviceId)}/>{measurePanel&&<MeasurementPanel key={(measurePanel.id||'nuova')+(measurePanel.deviceId||'')} project={project} measurementId={measurePanel.id} deviceId={measurePanel.deviceId} onClose={()=>setMeasurePanel(null)} onApply={next=>{if(commit(next,'measurement_placement'))setMeasurePanel(null);}}/>}
 <Modal className="device-modal" title={node ? `${node.sigla} · ${node.label}` : 'Apparecchio'} open={!!node && !drawer} onCancel={() => setSelected(null)} centered width={860} footer={<Button type="primary" onClick={() => setSelected(null)}>Chiudi caratteristiche</Button>}>{node && <Inspector key={node.id} expanded node={node} project={project} edit={edit} connect={parent => askConnection(node.id, parent)} remove={() => setRemoveId(node.id)}/>}</Modal>
 <Drawer title={{ scan: 'Documento e lettura visiva', settings: 'Impostazioni quadro', add: 'Aggiungi apparecchio', memory: 'Memoria di apprendimento', review: 'Controlli del progetto' }[drawer || ''] || ''} open={!!drawer && drawer !== 'guided'} onClose={() => setDrawer(null)} size={drawer === 'scan' ? 'large' : 'default'}>
 {drawer === 'scan' && <Scan project={project} onSelect={id => { setSelected(id); setDrawer(null); }}/>}
 {drawer === 'settings' && <><MhqUpload project={project} disabled={!!busy} onChange={next => commit({ ...current.current, hasMhq: next.hasMhq, mhq: next.mhq }, 'mhq_upload')}/><Collapse style={{marginBottom:16}} items={[{key:'cover',label:'Copertina · dati quadro',children:<><p className="muted">Seconda pagina. Elenco e totale fogli sono calcolati dal disegno; i dati non compilati restano mancanti.</p>{[['voltage','Tensione nominale V'],['current','Corrente nominale A'],['frequency','Frequenza Hz'],['ip','Grado IP'],['form','Forma di segregazione']].map(([key,label])=><TextEdit key={key} label={label} value={project.board?.[key] || ''} onChange={value=>commit({...current.current,board:{...current.current.board,[key]:value}},'cover_data')}/>)}</>}]} /><TextEdit label="Nome del quadro" value={project.name} onChange={name => commit({ ...project, name }, 'project_settings')}/><TextEdit label="Matricola" value={project.matricola} onChange={matricola => { const next: Project = { ...project, matricola }; delete next.mhq; commit(next, 'project_settings'); }}/>{['ka3', 'ka1'].map(k => <label className="field" key={k}>{k === 'ka3' ? 'kA a 400 V' : 'kA a 230 V'}<InputNumber key={String(project.settings[k as 'ka3'])} min={.1} defaultValue={project.settings[k as 'ka3']} onBlur={e => { const v = Number(e.target.value); if (Number.isFinite(v) && v > 0 && v !== project.settings[k as 'ka3'])
        void applySettings(k, v); }}/></label>)}<label className="field">Riferimento<Select value={project.settings.basis} options={['Icu', 'Icn'].map(value => ({ value, label: value }))} onChange={v => void applySettings('basis', v)}/></label>{project.boardRequirements && <><Alert type="warning" title={`Requisiti PDF: ${project.boardRequirements.ka3 ?? '?'} / ${project.boardRequirements.ka1 ?? '?'} kA · ${project.boardRequirements.basis || 'riferimento da verificare'}`}/><Checkbox checked={!!project.boardRequirements.confirmed} onChange={e => commit({ ...project, boardRequirements: { ...project.boardRequirements, confirmed: e.target.checked } }, 'board_confirmation')}>Requisiti verificati</Checkbox></>}<Button block onClick={async () => { setBusy({ message: 'Ricerca MHQ…' }); try {
        const mhq = await api<any>('/api/mhq', { matricola: project.matricola });
        commit({ ...project, mhq }, 'mhq_import');
    }
    catch (e) {
        setNotice(String(e));
    }
    finally {
        setBusy(null);
    } }} disabled={!project.matricola}>Cerca fronte MHQ</Button>{project.mhq && <p>{project.mhq.status} · {project.mhq.message || project.mhq.relativePath}</p>}{project.mhq?.status === 'ready' && <Checkbox checked={!!project.mhq.confirmed} onChange={e => commit({ ...project, mhq: { ...project.mhq, confirmed: e.target.checked } }, 'mhq_confirmation')}>Fronte verificato</Checkbox>}</>}
 {drawer === 'add' && <><label className="field">Funzione<Select value={request.kind} onChange={kind => setRequest({ ...request, kind })} options={[{ value: 'MTD', label: 'Magnetotermico differenziale' }, { value: 'MT', label: 'Magnetotermico' }, { value: 'RCD', label: 'Differenziale puro' }, { value: 'QS', label: 'Sezionatore' }]}/></label><TextEdit label="Utenza" value={request.label} onChange={label => setRequest({ ...request, label })}/><label className="field">Poli<Select value={request.poles} onChange={poles => setRequest({ ...request, poles })} options={['4P', '3P', '2P', '1P+N', '1P'].map(value => ({ value, label: value }))}/></label>{(['current', 'voltage', 'diff_mA'] as const).map(k => <label className="field" key={k}>{{ current: 'Corrente A', voltage: 'Tensione V', diff_mA: 'Soglia mA' }[k]}<InputNumber value={request[k]} onChange={v => setRequest({ ...request, [k]: v || 0 })}/></label>)}<TextEdit label="Curva" value={request.curve} onChange={curve => setRequest({ ...request, curve })}/><TextEdit label="Tipo differenziale" value={request.diff_type} onChange={diff_type => setRequest({ ...request, diff_type })}/><p className="muted">{node ? `Sarà inserito a valle di ${node.sigla}.` : 'L’alimentazione andrà verificata dopo l’inserimento.'}</p><Button type="primary" block onClick={add}>Proponi dal catalogo</Button></>}
 {drawer === 'memory' && <><p>Le correzioni sono salvate con il contesto. Il riutilizzo richiede la tua revisione.</p><p>{memory?.entries?.length || 0} correzioni · {learning.pending} da sincronizzare</p><Collapse items={[...(memory?.rules || []).map((r: any) => ({ key: r.id, label: r.scope || r.id, children: <p>{r.rule}</p> })), ...(memory?.entries || []).slice().reverse().map((r: any) => ({ key: r.id, label: `${r.sigla || 'Progetto'} · ${r.field}`, children: <><p>{String(r.before)} → {String(r.after)}</p><small>{r.sourceProject} · pagina {r.page || '—'}</small></> }))]}/></>}
 {drawer === 'review' && <><Alert title="La conferma delle schede non risolve automaticamente letture ambigue o componenti mancanti." type="info"/><p>{pending} schede · {ambiguities} campi ambigui</p><p>{project.unresolvedComponents?.filter((c: any) => c.requiresIntegration).length || 0} componenti da integrare · {project.measurementAssemblies?.filter((m: any) => m.requiresIntegration).length || 0} misure da integrare</p><Button onClick={() => { const next = clone(project); for (const n of next.nodes) {
        n.confirmed = true;
        n.connectionConfirmed = !unresolved(n) && n.connectionReview?.status !== 'proposed';
    } commit(next, 'batch_confirmation'); }}>Conferma schede non ambigue</Button><p><a href="/legacy.html" onClick={() => localStorage.setItem(DRAFT_KEY, JSON.stringify(project))}>Apri verifiche specialistiche nell’editor precedente</a></p><Collapse items={[{ key: 'components', label: 'Componenti rilevati e non integrati', children: <pre>{JSON.stringify(project.unresolvedComponents || [], null, 2)}</pre> }]}/></>}
 </Drawer>
 <Modal zIndex={2200} title={pendingLink?.parent ? "Inserire a valle?" : "Confermare ingresso esterno?"} open={!!pendingLink} onCancel={() => setPendingLink(null)} onOk={connect} okText="Collega e disponi" cancelText="Annulla"><p><b>{project.nodes.find(n => n.id === pendingLink?.child)?.sigla}</b> sarà alimentato da <b>{pendingLink?.parent ? project.nodes.find(n => n.id === pendingLink.parent)?.sigla : 'ingresso esterno'}</b>.</p><p>Il ramo verrà disposto sotto il padre. Questa relazione sarà usata anche nel disegno CAD.</p></Modal>
 <Modal title="Svuotare il progetto corrente?" open={clearOpen} onCancel={() => setClearOpen(false)} onOk={clear} okText="Svuota tutto" okButtonProps={{ danger: true }} cancelText="Annulla"><p>Rimuove tutti i blocchi, il PDF associato e i dati del quadro da questa sessione. La memoria di apprendimento e i progetti salvati restano disponibili.</p></Modal>
 <Modal title="Rimuovere l’apparecchio?" open={!!removeId} onCancel={() => setRemoveId(null)} onOk={() => { const next = clone(project); next.nodes = next.nodes.filter(n => n.id !== removeId).map(n => n.parent === removeId ? { ...n, parent: null, connectionConfirmed: false, connectionStatus: 'da_definire' } : n); next.nodes = layoutHierarchy(next.nodes); commit(next, 'remove_device'); setSelected(null); setRemoveId(null); }} okText="Rimuovi" cancelText="Annulla"><p>I figli rimarranno nel diagramma con alimentazione da definire.</p></Modal>
 <Modal title="Progetti salvati" open={files !== null} footer={null} onCancel={() => setFiles(null)}>{files?.length ? files.map(id => <Button key={id} block onClick={async () => { try {
        setProject(prepare(await api<Project>('/api/projects/' + encodeURIComponent(id))));
        setSavedId(id); setReviewOpen(false); setLiveProject(null); setResult(null);
        setHistory([]);
        setSelected(null);
        setFiles(null);
    }
    catch (e) {
        setNotice(String(e));
    } }}>{id}</Button>) : <Empty description="Nessun progetto salvato"/>}</Modal>
 <Modal title={result?.draft ? 'BOZZA · da verificare' : 'Risultato generazione'} open={!!result} onCancel={() => setResult(null)} footer={<Button onClick={() => setResult(null)}>Chiudi</Button>}>{result && <><p>{result.pages || '—'} pagine · {result.devices || project.nodes.length} apparecchi</p>{result.draft && <Alert type="warning" title="Bozza: può contenere dati incerti o componenti non ancora integrati."/>}<Space>{(['pdf', 'dwg', 'dxf', 'report'] as const).map(k => result[k] && <a key={k} href={result[k]} target="_blank" rel="noreferrer">{k.toUpperCase()}</a>)}</Space><p>{result.warning || result.destinationWarning}</p>{result.savedFiles && <div><b>File salvati in:</b>{Object.entries(result.savedFiles).map(([kind,path])=><p key={kind} style={{overflowWrap:'anywhere'}}>{path}</p>)}</div>}</>}</Modal>
 <Modal title={busy?.live ? 'Disegno AutoCAD in tempo reale' : 'Elaborazione'} width={busy?.live ? 1000 : 520} open={!!busy && !busy.importing} closable={false} maskClosable={false} footer={busy?.importing ? <Button onClick={() => { generation.current++; abort.current?.abort(); setBusy(null); setNotice('Attesa annullata. Il motore può terminare l’analisi in background.'); }}>Annulla attesa</Button> : null}><p>{busy?.message}</p>{busy?.live && <LiveDrawing active onDone={() => liveDone.current?.()}/>}<Progress percent={busy?.percent || 0} status="active" showInfo={busy?.percent !== undefined}/></Modal>
 {reviewProject && !busy && cableReviewOpen && <CableTypeReview project={reviewProject} onClose={()=>setCableReviewOpen(false)} onApply={next=>{stageChange(next);setCableReviewOpen(false);setNotice('Tipo di cavo applicato alle linee selezionate.');}}/>}
 {reviewProject && !busy && <Button style={{position:'fixed',bottom:20,right:24,zIndex:1500}} onClick={()=>setCableReviewOpen(true)}>Tipo cavo / guaina</Button>}
 <PdfReview key={reviewProject?.sourcePdf || liveProject?.sourcePdf || 'pending'} open={reviewOpen && (!!reviewProject || !!busy?.importing)} project={busy?.importing ? null : reviewProject} live={liveProject} busy={busy?.importing ? busy : null} onChange={stageChange} onClose={() => setReviewOpen(false)} onCancel={() => { generation.current++; abort.current?.abort(); setBusy(null); setReviewOpen(false); }} onCreate={() => { if (!reviewProject)
        return; setProject(prepare({ ...reviewProject, diagramLayoutVersion: 0 })); setSavedId(null); setHistory([]); setSelected(null); setReviewProject(null); setLiveProject(null); setReviewOpen(false); setNotice('Diagramma creato dai rilevamenti revisionati. Le incertezze rimangono segnalate.'); }}/>
 </div></ConfigProvider>;
}











