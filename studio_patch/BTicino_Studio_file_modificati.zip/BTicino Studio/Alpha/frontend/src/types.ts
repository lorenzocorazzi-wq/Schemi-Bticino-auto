export interface FieldReview {
    status: string;
    preview?: string;
    raw?: string;
    alternatives?: string[];
    [key: string]: unknown;
}
export interface Device {
    id: string;
    parent: string | null;
    sigla: string;
    kind: string;
    label: string;
    x?: number;
    y?: number;
    width?: number;
    height?: number;
    depth?: number;
    articles?: string[];
    values: Record<string, any>;
    confirmed?: boolean;
    connectionConfirmed?: boolean;
    connectionStatus?: string;
    connectionReview?: Record<string, any>;
    imported?: boolean;
    fieldReview?: Record<string, FieldReview>;
    evidence?: Record<string, any>;
    warnings?: string[];
    request?: Record<string, any>;
    [key: string]: any;
}
export interface MeasurementAssembly {
    id: string;
    page?: number | null;
    status?: string;
    articleProposal?: string | null;
    measuredFeeder?: string | null;
    measuredFeederConfirmed?: boolean;
    assignmentSource?: string;
    placement?: { mode: string; deviceId: string };
    ratio?: string | null;
    quantity?: number | null;
    relatedQuotationArticles?: string[];
    [key: string]: any;
}
export interface Settings {
    ka3: number;
    ka1: number;
    basis: string;
}
export interface Project {
    schemaVersion: number;
    name: string;
    settings: Settings;
    nodes: Device[];
    matricola?: string;
    sourcePdf?: string;
    scanPreview?: ScanPage[];
    [key: string]: any;
}
export interface ScanPage {
    page: number;
    image: string;
    width: number;
    height: number;
    bus?: {
        y: number;
        segments?: {
            x0: number;
            x1: number;
            devices: string[];
        }[];
    };
    nodes: {
        id?: string;
        sigla: string;
        axis?: number;
        articleBox?: number[];
        article?: string;
        label?: string;
        connection?: Record<string, any>;
    }[];
    [key: string]: any;
}
export interface Bootstrap {
    appId: string;
    version: string;
    projects: string[];
    lastImport?: Project;
    symbols?: Record<string, any>;
}
export interface ExportResult {
    savedFiles?: Record<string,string>;
    destinationWarning?: string;
    dwg?: string;
    pdf?: string;
    dxf?: string;
    report?: string;
    warning?: string;
    pages?: number;
    devices?: number;
}
export interface Correction {
    correctionId: string;
    sourceProject: string;
    sourcePdf: string;
    nodeId: string;
    sigla: string;
    article: string;
    field: string;
    before: unknown;
    after: unknown;
    page?: number;
    evidence: Record<string, unknown>;
}
export const DRAFT_KEY = 'bticino-alpha-draft';
export function emptyProject(): Project { return { schemaVersion: 1, name: 'Nuovo quadro', settings: { ka3: 10, ka1: 10, basis: 'Icu' }, nodes: [] }; }
export function unresolved(n: Device) { return n.connectionStatus === 'da_definire' || (!!n.imported && !n.parent && n.connectionStatus !== 'ingresso_esterno_esplicito'); }
