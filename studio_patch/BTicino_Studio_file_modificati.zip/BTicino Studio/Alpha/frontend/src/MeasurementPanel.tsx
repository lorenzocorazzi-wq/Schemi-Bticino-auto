import { useEffect, useMemo, useState } from 'react';
import { Alert, Button, InputNumber, Input, Modal, Radio, Select, Space } from 'antd';
import { api } from './api';
import type { MeasurementAssembly, Project } from './types';

type Option = { id: string; etichetta: string; disegnabile: boolean; motivo?: string | null };
type Options = { modi: Option[]; strumenti: { articolo: string; descrizione: string }[] };

const FALLBACK: Options = {
    modi: [
        { id: 'upstream_general', etichetta: 'A monte del generale', disegnabile: false, motivo: 'Disegno sull’arrivo linea ancora da integrare.' },
        { id: 'downstream_general', etichetta: 'A valle del generale', disegnabile: true },
        { id: 'downstream_device', etichetta: 'A valle di un’utenza', disegnabile: true },
    ],
    strumenti: [
        { articolo: 'MFD41ORFCDT', descrizione: 'Multifunzione con TA Rogowski' },
        { articolo: 'MFD4421', descrizione: 'Multifunzione con TA' },
    ],
};

type Props = {
    project: Project;
    /** null = nuova misura */
    measurementId: string | null;
    /** dispositivo preselezionato (es. dopo un trascinamento) */
    deviceId?: string | null;
    onClose: () => void;
    onApply: (project: Project) => void;
};

export function MeasurementPanel({ project, measurementId, deviceId, onClose, onApply }: Props) {
    const existing: MeasurementAssembly | undefined = (project.measurementAssemblies || []).find((m: MeasurementAssembly) => m.id === measurementId);
    const roots = useMemo(() => project.nodes.filter(n => !n.parent), [project.nodes]);
    const [options, setOptions] = useState<Options>(FALLBACK);
    const initialDevice = deviceId || existing?.measuredFeeder || null;
    const initialMode = existing?.placement?.mode
        || (initialDevice ? (roots.length === 1 && roots[0].id === initialDevice ? 'downstream_general' : 'downstream_device') : 'downstream_general');
    const [mode, setMode] = useState<string>(initialMode);
    const [device, setDevice] = useState<string | null>(initialDevice || (roots.length === 1 ? roots[0].id : null));
    const [instrument, setInstrument] = useState<string | null>(existing?.articleProposal || null);
    const [ratio, setRatio] = useState<string>(existing?.ratio || '');
    const [quantity, setQuantity] = useState<number | null>(existing?.quantity ?? null);
    const [error, setError] = useState('');
    const [busy, setBusy] = useState(false);

    useEffect(() => {
        let alive = true;
        api<any>('/api/measurement/options', { project }).then(o => { if (alive && o.modi) setOptions({ modi: o.modi, strumenti: o.strumenti }); }).catch(() => undefined);
        return () => { alive = false; };
    }, []);

    const candidates = mode === 'downstream_general' ? roots : project.nodes;
    const describe = (n: Project['nodes'][number]) => `${n.sigla} · ${n.values?.articolo || (n.articles || [])[0] || n.kind} · ${n.label}`;

    function pickMode(next: string) {
        setMode(next);
        if (next === 'downstream_general') setDevice(roots.length === 1 ? roots[0].id : null);
    }

    async function apply() {
        setError('');
        if (!device) { setError(mode === 'downstream_general' ? 'Scegli l’interruttore generale.' : 'Scegli l’interruttore dell’utenza misurata.'); return; }
        if (!existing && !instrument) { setError('Scegli lo strumento da inserire.'); return; }
        setBusy(true);
        try {
            const placement: Record<string, unknown> = { modo: mode, dispositivo: device };
            if (existing) placement.misura = existing.id;
            if (instrument) placement.strumento = instrument;
            if (ratio.trim()) placement.rapporto = ratio.trim();
            if (quantity !== null) placement.quantita = quantity;
            const result = await api<{ project: Project }>('/api/measurement/place', { project, placements: [placement] });
            onApply(result.project);
        } catch (e) {
            setError(e instanceof Error ? e.message : String(e));
        } finally {
            setBusy(false);
        }
    }

    function remove() {
        onApply({ ...project, measurementAssemblies: (project.measurementAssemblies || []).filter((m: MeasurementAssembly) => m.id !== measurementId) });
    }

    return <Modal open centered width={640} title={existing ? 'Multimetro e TA' : 'Aggiungi multimetro e TA'} onCancel={onClose}
        footer={<Space>{existing && <Button danger onClick={remove}>Rimuovi misura</Button>}<Button onClick={onClose}>Annulla</Button><Button type="primary" loading={busy} onClick={() => void apply()}>{existing ? 'Applica' : 'Inserisci'}</Button></Space>}>
        <div className="measurement-panel">
            <div className="field"><span>1 · Dove vuoi misurare</span>
                <Radio.Group value={mode} onChange={e => pickMode(e.target.value)}>
                    {options.modi.map(m => <Radio.Button key={m.id} value={m.id} disabled={!m.disegnabile} title={m.motivo || undefined}>{m.etichetta}</Radio.Button>)}
                </Radio.Group>
                {options.modi.some(m => !m.disegnabile) && <small>{options.modi.filter(m => !m.disegnabile).map(m => `${m.etichetta}: ${m.motivo}`).join(' ')}</small>}
            </div>
            <div className="field"><span>2 · {mode === 'downstream_general' ? 'Interruttore generale' : 'Interruttore dell’utenza'}</span>
                <Select showSearch value={device} onChange={setDevice} placeholder="Scegli l’interruttore" optionFilterProp="label"
                    options={candidates.map(n => ({ value: n.id, label: describe(n) }))}/>
            </div>
            <div className="field"><span>3 · Strumento</span>
                <Select value={instrument} onChange={setInstrument} placeholder="Scegli lo strumento"
                    options={options.strumenti.map(s => ({ value: s.articolo, label: `${s.articolo} · ${s.descrizione}` }))}/>
            </div>
            <div className="measurement-row">
                <div className="field"><span>Rapporto TA (es. 100/5)</span><Input value={ratio} onChange={e => setRatio(e.target.value)} placeholder="Da confermare"/></div>
                <div className="field"><span>Quantità TA</span><InputNumber min={1} max={3} value={quantity} onChange={v => setQuantity(v)} placeholder="Da confermare"/></div>
            </div>
            <small>Il TA viene collocato sul primario dell’interruttore scelto: le utenze a valle ripartono dopo il TA. Puoi spostarlo in seguito trascinando il TA su un altro blocco.</small>
            {error && <Alert type="error" title={error}/>}
        </div>
    </Modal>;
}
