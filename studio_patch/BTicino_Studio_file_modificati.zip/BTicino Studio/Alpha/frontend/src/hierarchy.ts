/** Electrical parent relationships are authoritative; layout never rewrites them. */
export interface DiagramNode {
    id: string;
    parent?: string | null;
    x?: number;
    y?: number;
    [key: string]: unknown;
}
export type LayoutNode<T extends DiagramNode = DiagramNode> = T & {
    x: number;
    y: number;
    width: number;
    height: number;
    depth: number;
    layoutIssue?: 'missing_parent' | 'cycle';
};
export interface ConnectionValidation {
    valid: boolean;
    reason?: string;
}
export interface Branch {
    parentId: string;
    childId: string;
    /** Distribution start below the parent. */
    busY: number;
    path: string;
}
function nodeMap<T extends DiagramNode>(nodes: readonly T[]): Map<string, T> {
    const map = new Map<string, T>();
    for (const node of nodes) {
        if (!node.id || map.has(node.id))
            throw new Error('Identificativo apparecchio mancante o duplicato.');
        map.set(node.id, node);
    }
    return map;
}
/** Reject both newly introduced cycles and attachment to an already invalid chain. */
export function validateConnection<T extends DiagramNode>(nodes: readonly T[], childId: string, parentId: string | null): ConnectionValidation {
    const map = nodeMap(nodes);
    if (!map.has(childId))
        return { valid: false, reason: 'Apparecchio non trovato.' };
    if (!parentId)
        return { valid: true };
    const seen = new Set<string>([childId]);
    let cursor: string | null | undefined = parentId;
    while (cursor) {
        if (seen.has(cursor))
            return { valid: false, reason: 'Questo collegamento crea un ciclo di alimentazione.' };
        seen.add(cursor);
        const node = map.get(cursor);
        if (!node)
            return { valid: false, reason: 'Alimentazione non trovata: verificare il riferimento.' };
        cursor = node.parent;
    }
    return { valid: true };
}
/** Changing a connection is an operator proposal; separate confirmation remains required. */
export function reparentNode<T extends DiagramNode>(nodes: readonly T[], childId: string, parentId: string | null): T[] {
    const check = validateConnection(nodes, childId, parentId);
    if (!check.valid)
        throw new Error(check.reason);
    return nodes.map(node => {
        if (node.id !== childId)
            return { ...node };
        const review = node.connectionReview;
        return {
            ...node,
            parent: parentId || null,
            connectionStatus: parentId ? 'scelta_operatore' : 'ingresso_esterno_esplicito',
            connectionConfirmed: false,
            connectionReview: {
                ...(review && typeof review === 'object' ? review : {}),
                status: 'operator_choice',
            },
        };
    });
}
/**
 * Compact vertical forest. Invalid chains remain visible with a diagnostic,
 * retaining their actual parent fields (no invented external supplies).
 */
/** `extraBelow`: spazio verticale riservato sotto un blocco (es. multimetro con TA). */
export function layoutHierarchy<T extends DiagramNode>(nodes: readonly T[], availableWidth = 420, extraBelow: ReadonlyMap<string, number> = new Map()): LayoutNode<T>[] {
    const map = nodeMap(nodes);
    const cycles = new Set<string>();
    for (const node of nodes) {
        const path: string[] = [];
        const seen = new Map<string, number>();
        let cursor: string | null | undefined = node.id;
        while (cursor && map.has(cursor)) {
            const repeated = seen.get(cursor);
            if (repeated !== undefined) {
                for (const member of path.slice(repeated))
                    cycles.add(member);
                break;
            }
            seen.set(cursor, path.length);
            path.push(cursor);
            cursor = map.get(cursor)!.parent;
        }
    }
    const children = new Map<string, string[]>();
    const roots: string[] = [];
    for (const node of nodes) {
        if (!node.parent || !map.has(node.parent) || cycles.has(node.id))
            roots.push(node.id);
        else {
            const siblings = children.get(node.parent) || [];
            siblings.push(node.id);
            children.set(node.parent, siblings);
        }
    }
    const sizes = new Map<string, {
        width: number;
        height: number;
        span: number;
        treeHeight: number;
        depth: number;
        columns: number;
    }>();
    const measure = (id: string, depth: number): number => {
        const width = Math.max(288, 360 - depth * 24);
        const height = 126;
        const kids = children.get(id) || [];
        const descendants = Math.max(0, ...kids.map(child => measure(child, depth + 1))) + (kids.length ? 40 : 0);
        const span = Math.max(width, descendants);
        const leafChildren = kids.length > 0 && kids.every(child => !(children.get(child)?.length));
        const childWidth = Math.max(288, 360 - (depth + 1) * 24);
        const usableWidth = Math.max(childWidth, availableWidth - 84 - depth * 40);
        const columns = leafChildren ? Math.max(1, Math.min(3, kids.length, Math.floor((usableWidth + 28) / (childWidth + 28)))) : 1;
        if (leafChildren && availableWidth > 420) {
            // Fill the available desktop width without scaling down the text.
            const expandedWidth = Math.min(520, Math.max(childWidth, (usableWidth - (columns - 1) * 28) / columns));
            for (const child of kids) sizes.get(child)!.width = expandedWidth;
        }
        const treeHeight = height + (extraBelow.get(id) || 0) + (columns > 1 ? Math.ceil(kids.length / columns) * (126 + 28) : kids.reduce((sum, child) => sum + 18 + sizes.get(child)!.treeHeight, 0));
        sizes.set(id, { width, height, span, treeHeight, depth, columns });
        return span;
    };
    roots.forEach(id => measure(id, 0));
    const placed = new Map<string, LayoutNode<T>>();
    const place = (id: string, left: number, top: number): void => {
        const node = map.get(id)!;
        const size = sizes.get(id)!;
        const { layoutIssue: _staleIssue, ...metadata } = node;
        const output = {
            ...metadata, x: left, y: top,
            width: size.width, height: size.height, depth: size.depth,
        } as LayoutNode<T>;
        if (cycles.has(id))
            output.layoutIssue = 'cycle';
        else if (node.parent && !map.has(node.parent))
            output.layoutIssue = 'missing_parent';
        placed.set(id, output);
        const kids = children.get(id) || [];
        let childTop = top + size.height + 18 + (extraBelow.get(id) || 0);
        for (const [index, child] of kids.entries()) {
            const column = index % size.columns;
            place(child, left + 40 + column * (sizes.get(child)!.width + 28), childTop);
            if (column === size.columns - 1) childTop += sizes.get(child)!.treeHeight + (size.columns > 1 ? 28 : 18);
        }
    };
    let rootTop = 20;
    for (const root of roots) {
        const size = sizes.get(root)!;
        // Independent supplies form a vertical list; connected descendants stay together.
        place(root, 20, rootTop);
        rootTop += size.treeHeight + 28;
    }
    return nodes.map(node => placed.get(node.id)!);
}
/** Orthogonal electrical branches: vertical trunk and side entries. */
export function orthogonalBranches<T extends DiagramNode>(nodes: readonly LayoutNode<T>[]): Branch[] {
    const map = nodeMap(nodes);
    const groups = new Map<string, LayoutNode<T>[]>();
    for (const node of nodes) {
        if (!node.parent || node.layoutIssue)
            continue;
        const parent = map.get(node.parent);
        if (!parent || node.y <= parent.y + parent.height)
            continue;
        const kids = groups.get(parent.id) || [];
        kids.push(node);
        groups.set(parent.id, kids);
    }
    const result: Branch[] = [];
    for (const [parentId, children] of groups) {
        const parent = map.get(parentId)!;
        const px = parent.x + 16;
        const py = parent.y + parent.height;
        const busY = py + 8;
        for (const child of children) {
            const cx = child.x;
            result.push({ parentId, childId: child.id, busY,
                path: `M ${px} ${py} V ${child.y - 9} H ${cx - 12} V ${child.y + child.height / 2} H ${cx}` });
        }
    }
    return result;
}


