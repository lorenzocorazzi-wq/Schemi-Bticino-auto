"""Protected measurement group learned from as-built M26697 folios004/005."""
from measurement_drawing import load,insert,template_for
from typography import fit_caption

def prepare(doc,studio,assemblies):
 groups={}
 for index,r in enumerate(assemblies):
  feeder=r.get('measuredFeeder')
  operator_line=r.get('measuredFeederConfirmed') and r.get('assignmentSource')=='operator'
  # Tipico MFD4421 usato anche per altri strumenti: disegnato, ma marcato da confermare.
  r={**r,'templateValidated':r.get('articleProposal') in ('MFD4421','MFD41ORFCDT')}
  if not feeder or (not r.get('voltageProtection') and not operator_line):
   raise ValueError('Misura non disegnabile: completare linea, articolo e ramo protetto. Nessuna misura viene omessa.')
  if feeder in groups:raise ValueError('Piu misure sulla stessa linea: composizione ancora da definire.')
  groups[feeder]={'assembly':r,'sigla':'MU'+str(index+1),'protectionSigla':'FU'+str(index+1),'ctSigla':'TA'+str(index+1)}
 if groups:
  for r in groups.values():
   _,meta=load(doc,studio/'catalogo/moduli_misura',template_for(r['assembly'].get('articleProposal')))
   r.update(ports={p['id']:p['xy'] for p in meta['ports']},block=meta['id'],topAligned=meta['topAligned'])
 return groups

def draw(doc,group,x,sy,text,line,source,fieldrows,ceiling=None):
 m=doc.modelspace();r=group['assembly'];ports=group['ports'];top_y=sy+249 if ceiling is None else ceiling
 if group.get('topAligned') and top_y<sy+249:raise ValueError('Misura su barra troppo bassa per questo strumento: scegliere il modulo con TA o spostare la misura.')
 origin=(x+20,top_y-ports['PRIMARY_OUT'][1]) if group.get('topAligned') else (x+20,sy+159)
 values={a.dxf.tag:'?' for a in doc.blocks.get(group['block']).query('ATTDEF')}
 values.update(SIGLA_MISURA=group['sigla'],SIGLA_PROTEZIONE=group['protectionSigla'],RAPPORTO_TA=str(r.get('ratio') or '?'),QUANTITA_TA=str(r.get('quantity') or '?'))
 ref=insert(m,origin,values,group['block'])
 # In the own standard the primary rises from the protection output, passes
 # through the CT and continues across the top to the outgoing circuit.
 bottom=ports['PRIMARY_IN'];top=ports['PRIMARY_OUT']
 bottom=(origin[0]+bottom[0],origin[1]+bottom[1]);top=(origin[0]+top[0],origin[1]+top[1])
 line((x,sy+142.5),(bottom[0],sy+142.5));line((bottom[0],sy+142.5),bottom)
 if top[1]>top_y+.01:raise ValueError('Misura su barra troppo bassa: instradamento del primario senza spazio sotto la barra di alimentazione.')
 if top[1]<top_y:line(top,(top[0],top_y))
 line((top[0],top_y),(x+125,top_y));line((x+125,top_y),(x+125,sy+142.5));m.add_circle((x+125,sy+142.5),1.2)
 ref.add_attrib('MEASURED_FEEDER',r['measuredFeeder'],origin,dxfattribs={'flags':1,'height':1})
 if not group.get('topAligned'):text('AUX L/N DA VERIF.',x+91,top_y-6,1.4)
 protection=r.get('voltageProtection') or {}
 for column,sigla,article,label in [(x+25,group['ctSigla'],' / '.join(r.get('relatedQuotationArticles',[])) or 'DA VERIF.','ROGOWSKI - DA CONFERMARE' if 'ORF' in str(r.get('articleProposal')) else 'TA - DA CONFERMARE'),(x+50,group['protectionSigla'],protection.get('articleProposal') or 'DA VERIF.','PROTEZIONE MISURA' if protection else 'PROTEZIONE PROPOSTA'),(x+100,group['sigla'],r.get('articleProposal') or 'DA VERIF.','STRUMENTO MISURA' if r['templateValidated'] else 'STRUMENTO - DA CONFERMARE')]:
  text(sigla,column,sy+127.5,1.8);text(label,column,sy+118,1.3);text(article,column,sy+103,1.7)
 labels,height=fit_caption(source['label'])
 for i,label in enumerate(labels):text(label,x+125,sy+118+(len(labels)-1)*height*.725-i*height*1.45,height)
 for key in ['tipo_cavo','composizione_cavo','lunghezza_m']:
  value=source['values'].get(key,'')
  if source.get('fieldReview',{}).get(key,{}).get('status')=='ambiguous':value='DA VERIF.'
  if value:text(value,x+125,sy+fieldrows[key],1.8)
 return {'id':r['id'],'measuredFeeder':r['measuredFeeder'],'origin':list(origin),'sigla':group['sigla'],'ports':ports,'primaryDirection':'bottom_to_top_as_built','auxiliaryConnected':False,'ctSource':'detected' if r.get('ctGeometry') else 'native_template_proposal','protectionSource':'detected' if protection else 'native_template_proposal','instrumentSource':'validated_template' if r['templateValidated'] else 'template_da_confermare'}
