import json,pathlib,uuid,base64,threading,http.server,urllib.parse,sys,traceback,re
import os
from runtime_start import backend_revision
from engine import ROOT,STUDIO,select_device,example,export_project,SYMBOLS,CAT
import pymupdf
import live_preview
from pdf_import import interpret
from mhq_import import prepare,prepare_upload
from claude_fallback import status as vision_status,eligible as vision_eligible,recover as vision_recover
from learning_memory import read as read_learning_memory,record as record_learning_correction,suggestions as learning_suggestions
PROJECTS=ROOT/'projects';PROJECTS.mkdir(exist_ok=True);EXPORTS=ROOT/'exports';EXPORTS.mkdir(exist_ok=True)
PDF_JOBS={};PDF_JOBS_LOCK=threading.Lock()
LOADED_REVISION=backend_revision()
def run_pdf_job(job_id,raw,name,settings,folder,url,matricola):
 def update(value):
  with PDF_JOBS_LOCK:PDF_JOBS[job_id].update(value)
 try:
  update({'state':'running','phase':'avvio','percent':1,'message':'Avvio analisi locale del documento.'})
  result=interpret(raw,name,settings,folder,url,progress=lambda status:update(status))
  result['project']['learningSuggestions']=learning_suggestions(result['project'])
  result['project']['learningMemoryCount']=len(read_learning_memory().get('entries',[]));result['project']['learningRuleCount']=len(read_learning_memory().get('rules',[]))
  if matricola:
   result['project']['matricola']=matricola
   try:result['project']['mhq']=prepare(matricola)
   except Exception as error:result['project']['mhq']={'status':'error','message':str(error)}
  (folder/'interpretazione.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
  (ROOT/'last_import.json').write_text(json.dumps(result['project'],ensure_ascii=False,indent=2),encoding='utf-8')
  update({'state':'complete','phase':'completato','percent':100,'message':result['message'],'result':result})
 except Exception as error:
  update({'state':'error','phase':'errore','percent':100,'message':str(error)})
def safe(path,root):
 p=(root/path).resolve()
 if not p.is_relative_to(root.resolve()):raise ValueError('Percorso non valido.')
 return p
class Handler(http.server.BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def send_json(self,value,status=200):
  raw=json.dumps(value,ensure_ascii=False).encode();self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
 def do_GET(self):
  path=urllib.parse.unquote(urllib.parse.urlparse(self.path).path)
  try:
   if path=='/api/health':return self.send_json({'appId':'bticino-studio-alpha','backendRevision':LOADED_REVISION,'capabilities':['pdf_async','learning_memory','live_drawing'],'pid':os.getpid()})
   match=re.fullmatch(r'/api/pdf/status/([a-f0-9]{12})',path)
   if match:
    with PDF_JOBS_LOCK:job=PDF_JOBS.get(match[1])
    if not job:return self.send_json({'error':'Analisi PDF non trovata.'},404)
    return self.send_json({k:v for k,v in job.items() if k!='result'}|({'result':job['result']} if job.get('state')=='complete' else {}))
   if path=='/api/live':
    q=urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query);return self.send_json(live_preview.snapshot(int(q.get('v',['0'])[0]),int(q.get('since',['0'])[0])))
   if path=='/api/bootstrap':return self.send_json({'appId':'bticino-studio-alpha','version':'0.2 alpha','symbols':SYMBOLS,'projects':[p.stem for p in PROJECTS.glob('*.json')],'catalogueCount':len(CAT),'lastImport':json.loads((ROOT/'last_import.json').read_text(encoding='utf-8')) if (ROOT/'last_import.json').is_file() else None})
   if path=='/api/example':return self.send_json(example())
   if path=='/api/vision/status':return self.send_json(vision_status())
   if path=='/api/learning':return self.send_json(read_learning_memory())
   if path.startswith('/api/projects/'):
    p=safe(path[len('/api/projects/'):]+'.json',PROJECTS);return self.send_json(json.loads(p.read_text(encoding='utf-8')))
   root=STUDIO if path.startswith('/assets/') else ROOT
   target=safe(path[len('/assets/'):] if path.startswith('/assets/') else path.lstrip('/') or 'index.html',root)
   if not target.is_file():return self.send_json({'error':'File non trovato'},404)
   mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css','.png':'image/png','.pdf':'application/pdf','.json':'application/json'}.get(target.suffix,'application/octet-stream');raw=target.read_bytes();self.send_response(200);self.send_header('Content-Type',mime);self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
  except Exception as e:self.send_json({'error':str(e)},400)
 def do_POST(self):
  try:
   origin=self.headers.get('Origin','')
   port=self.server.server_address[1]
   if origin and origin not in [f'http://127.0.0.1:{port}',f'http://localhost:{port}']:raise ValueError('Origine non autorizzata.')
   length=int(self.headers.get('Content-Length',0))
   if length>70_000_000:raise ValueError('File troppo grande.')
   data=json.loads(self.rfile.read(length));path=urllib.parse.urlparse(self.path).path
   if path=='/api/learning/correction':return self.send_json(record_learning_correction(data.get('entry')))
   if path=='/api/measurement/options':
    from measurement_placement import opzioni
    return self.send_json(opzioni(data['project']))
   if path=='/api/measurement/place':
    from measurement_placement import posiziona
    return self.send_json({'project':posiziona(data['project'],data.get('placements',[]))})
   if path=='/api/select':return self.send_json(select_device(data['request'],data['settings']))
   if path=='/api/save':
    p=data['project'];key=data.get('id') or uuid.uuid4().hex[:10];target=safe(key+'.json',PROJECTS);target.write_text(json.dumps(p,ensure_ascii=False,indent=2),encoding='utf-8');reply={'id':key,'name':p.get('name','Progetto')}
    if data.get('askLocation'):
     from project_save_dialog import save_as,suggested_name
     try:
      chosen=save_as(p)
      if chosen is None:reply['cancelled']=True
      else:reply['savedPath']=chosen
     except RuntimeError as error:reply['dialogUnavailable']=str(error);reply['suggestedName']=suggested_name(p)
    return self.send_json(reply)
   if path in ('/api/export','/api/preview'):
    from export_destination import destination,save_result
    project=data['project'];folder=destination(project);draft=path=='/api/preview'
    live_preview.start()
    try:result=export_project(project,preview_only=draft,native_preview=draft)
    except Exception as error:live_preview.fail(str(error));raise
    live_preview.phase('Completato.')
    return self.send_json(save_result(result,folder,ROOT,project,draft))
   if path=='/api/vision/plan':return self.send_json({'requests':vision_eligible(data['project']),**vision_status()})
   if path=='/api/vision/recover':
    p=data['project'];source=p.get('sourcePdf','')
    if not re.fullmatch(r'/exports/[a-f0-9]{10,12}/input\.pdf',source):raise ValueError('Usare il PDF caricato nel programma per il recupero Claude.')
    pdf=safe(source.lstrip('/'),ROOT)
    result=vision_recover(p,pdf,data.get('pages',[]),data.get('consent') is True)
    destination=pdf.parent/('claude_proposte_'+uuid.uuid4().hex[:8]+'.json')
    destination.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    result['reviewFile']='/'+destination.relative_to(ROOT).as_posix()
    return self.send_json(result)
   if path=='/api/pdf/start':
    raw=base64.b64decode(data['base64'],validate=True);pdfid=uuid.uuid4().hex[:12];folder=EXPORTS/pdfid;folder.mkdir();(folder/'input.pdf').write_bytes(raw)
    match=re.search(r'\bM\d{5}\b',data.get('name','').upper());matricola=data.get('matricola') or (match.group() if match else None)
    with PDF_JOBS_LOCK:PDF_JOBS[pdfid]={'state':'queued','phase':'in_coda','percent':0,'message':'Documento acquisito.','sourcePdf':f'/exports/{pdfid}/input.pdf'}
    threading.Thread(target=run_pdf_job,args=(pdfid,raw,data.get('name','Progetto PDF'),data.get('settings',{'ka3':10,'ka1':10,'basis':'Icu'}),folder,f'/exports/{pdfid}/input.pdf',matricola),daemon=True).start()
    return self.send_json({'jobId':pdfid,'state':'queued'})
   if path=='/api/mhq/upload':
    encoded=data.get('base64','')
    if not isinstance(encoded,str) or len(encoded)>42_000_000:raise ValueError('Il file MHQ deve essere di massimo 30 MB.')
    return self.send_json(prepare_upload(base64.b64decode(encoded,validate=True),data.get('name',''),data.get('matricola','')))
   if path=='/api/mhq':return self.send_json(prepare(data['matricola'],data.get('relativePath')))
   if path=='/api/pdf':
    raw=base64.b64decode(data['base64'],validate=True);pdfid=uuid.uuid4().hex[:10];folder=EXPORTS/pdfid;folder.mkdir();(folder/'input.pdf').write_bytes(raw)
    result=interpret(raw,data.get('name','Progetto PDF'),data.get('settings',{'ka3':10,'ka1':10,'basis':'Icu'}),folder,f'/exports/{pdfid}/input.pdf')
    result['project']['learningSuggestions']=learning_suggestions(result['project'])
    result['project']['learningMemoryCount']=len(read_learning_memory().get('entries',[]));result['project']['learningRuleCount']=len(read_learning_memory().get('rules',[]))
    match=re.search(r'\bM\d{5}\b',data.get('name','').upper())
    matricola=data.get('matricola') or (match.group() if match else None)
    if matricola:
     result['project']['matricola']=matricola
     try:result['project']['mhq']=prepare(matricola)
     except Exception as error:result['project']['mhq']={'status':'error','message':str(error)}
    (folder/'interpretazione.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8');(ROOT/'last_import.json').write_text(json.dumps(result['project'],ensure_ascii=False,indent=2),encoding='utf-8')
    return self.send_json(result)
   self.send_json({'error':'Operazione sconosciuta'},404)
  except Exception as e:self.send_json({'error':str(e)},400)
if __name__=='__main__':
 port=int(os.environ.get('BTICINO_PORT','8765'))
 print(f'BTicino Alpha: http://127.0.0.1:{port}',flush=True)
 http.server.ThreadingHTTPServer(('127.0.0.1',port),Handler).serve_forever()
