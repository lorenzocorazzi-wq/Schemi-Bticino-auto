"""Correzione delle denominazioni delle utenze lette dall'OCR.

I nomi nelle tabelle dei PDF sono tracciati a mano (font CAD a tratto singolo):
l'OCR li scambia spesso (U/O, I/T, L/C...). Si correggono con il vocabolario dei
disegni dello studio (``catalogo/vocabolario_utenze.json``, ricavato dai DXF
as-built) e con confusioni tipiche dell'OCR. Una parola italiana valida non si
tocca mai (elenco generale ``catalogo/parole_it.txt.gz``) e un candidato non
univoco lascia la parola com'e'. Il risultato resta una proposta da confermare.
"""
from __future__ import annotations

import gzip
import json
import re
from functools import lru_cache
from pathlib import Path

CATALOGO = Path(__file__).resolve().parents[1] / 'catalogo'
COSTO_INDEL = .7
COSTO_CONFUSIONE = .35
CONFUSIONI = {frozenset(p) for p in ('UO', 'IT', 'LC', 'LI', 'EF', 'RK', 'UC', 'CO', 'GC', 'OQ', 'DO', 'BR', 'AH', 'NM', 'VU', 'IJ')}
_PAROLA = re.compile(r"[A-Za-zÀ-ÿ']+")


@lru_cache(maxsize=1)
def dominio() -> dict[str, int]:
    percorso = CATALOGO / 'vocabolario_utenze.json'
    return json.loads(percorso.read_text(encoding='utf-8')) if percorso.is_file() else {}


@lru_cache(maxsize=1)
def generale() -> frozenset[str]:
    percorso = CATALOGO / 'parole_it.txt.gz'
    if not percorso.is_file():
        return frozenset()
    with gzip.open(percorso, 'rt', encoding='utf-8') as file:
        return frozenset(riga.strip() for riga in file)


def distanza(a: str, b: str, limite: float) -> float:
    """Levenshtein pesata: le confusioni OCR costano meno di una sostituzione qualsiasi."""
    if abs(len(a) - len(b)) * COSTO_INDEL > limite:
        return limite + 1
    precedente = [j * COSTO_INDEL for j in range(len(b) + 1)]
    for i in range(1, len(a) + 1):
        corrente = [i * COSTO_INDEL] + [0.0] * len(b)
        for j in range(1, len(b) + 1):
            if a[i - 1] == b[j - 1]:
                sost = 0.0
            else:
                sost = COSTO_CONFUSIONE if frozenset((a[i - 1], b[j - 1])) in CONFUSIONI else 1.0
            corrente[j] = min(precedente[j] + COSTO_INDEL, corrente[j - 1] + COSTO_INDEL, precedente[j - 1] + sost)
        if min(corrente) > limite:
            return limite + 1
        precedente = corrente
    return precedente[-1]


def correggi_parola(parola: str, voc: dict[str, int] | None = None, valide: frozenset[str] | None = None) -> str:
    voc = dominio() if voc is None else voc
    valide = generale() if valide is None else valide
    maiuscola = parola.upper()
    if len(maiuscola) < 4 or maiuscola in voc or maiuscola in valide:
        return parola
    limite = min(2.2, .30 * len(maiuscola) + .3)
    candidati = sorted((distanza(maiuscola, w, limite), -c, w) for w, c in voc.items() if len(w) >= 4)
    if candidati and candidati[0][0] <= limite:
        migliore = candidati[0]
        for altro in candidati[1:4]:
            if altro[2] != migliore[2] and altro[0] - migliore[0] < .15 and -altro[1] * 4 >= -migliore[1]:
                return parola  # candidati equivalenti: non scegliere
        return migliore[2]
    # Parola non del vocabolario dello studio: solo il dizionario generale, con soglia piu' stretta e candidato unico.
    stretto = min(1.1, limite)
    vicini = sorted((distanza(maiuscola, w, stretto), w) for w in valide if abs(len(w) - len(maiuscola)) <= 1)
    vicini = [v for v in vicini if v[0] <= stretto]
    if len(vicini) >= 1 and (len(vicini) == 1 or vicini[1][0] - vicini[0][0] >= .3):
        return vicini[0][1]
    return parola


@lru_cache(maxsize=4096)
def _corretta(parola: str) -> str:
    return correggi_parola(parola)


def correggi_etichetta(testo: str, voc: dict[str, int] | None = None, valide: frozenset[str] | None = None) -> tuple[str, list[dict]]:
    """Testo corretto e elenco delle sostituzioni {da, a}; i token con cifre non si toccano."""
    modifiche: list[dict] = []
    usa_cache = voc is None and valide is None

    def sostituisci(match: re.Match) -> str:
        parola = match.group(0)
        nuova = _corretta(parola) if usa_cache else correggi_parola(parola, voc, valide)
        if nuova.upper() != parola.upper() or (nuova != parola and parola != parola.upper()):
            modifiche.append({'da': parola, 'a': nuova})
        return nuova

    return _PAROLA.sub(sostituisci, testo), modifiche
