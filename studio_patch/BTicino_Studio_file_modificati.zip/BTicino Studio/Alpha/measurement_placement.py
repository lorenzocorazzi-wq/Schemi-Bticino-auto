"""Posizionamento scelto dall'operatore per i moduli di misura (multimetro + TA).

Prima di disegnare una misura il sistema chiede:
  1. dove va collocata (modo);
  2. su quale interruttore (dispositivo);
  3. quale strumento (articolo), solo per misure non rilevate dal PDF.

Modi:
  upstream_general    a monte del generale: TA sull'arrivo linea, prima del generale
  downstream_general  a valle del generale: TA sull'uscita del generale
  downstream_device   a valle di un'utenza: TA sull'uscita dell'interruttore scelto

Il motore di disegno riceve solo `measuredFeeder`, `measuredFeederConfirmed` e
`assignmentSource`; qui si ricavano da modo e dispositivo, con le verifiche.
"""
from __future__ import annotations

import copy
import uuid

MODI = {
    'upstream_general': 'A monte del generale',
    'downstream_general': 'A valle del generale',
    'downstream_device': 'A valle di un\'utenza',
}
MODI_DISEGNABILI = {'downstream_general', 'downstream_device'}
STRUMENTI = {
    'MFD41ORFCDT': 'Multifunzione con TA Rogowski',
    'MFD4421': 'Multifunzione con TA',
}


def _nodi(progetto: dict) -> dict:
    return {n['id']: n for n in progetto.get('nodes', [])}


def _radici(progetto: dict) -> list[dict]:
    return [n for n in progetto.get('nodes', []) if not n.get('parent')]


def _descrizione(nodo: dict) -> dict:
    valori = nodo.get('values', {})
    return {
        'id': nodo['id'],
        'sigla': nodo.get('sigla'),
        'articolo': valori.get('articolo') or (nodo.get('articles') or [None])[0],
        'utenza': nodo.get('label'),
        'padre': nodo.get('parent'),
        'pagina': nodo.get('evidence', {}).get('page'),
    }


def modo_proposto(progetto: dict, dispositivo: str | None) -> str | None:
    """Modo ricavato dal dispositivo rilevato: solo un suggerimento da confermare."""
    nodi = _nodi(progetto)
    nodo = nodi.get(dispositivo)
    if nodo is None:
        return None
    radici = _radici(progetto)
    if not nodo.get('parent') and len(radici) == 1:
        return 'downstream_general'
    return 'downstream_device'


def opzioni(progetto: dict) -> dict:
    """Domande da porre all'operatore, con candidati e proposte per le misure già rilevate."""
    radici = _radici(progetto)
    generali = radici if len(radici) == 1 else []
    misure = []
    for misura in progetto.get('measurementAssemblies', []):
        proposta = misura.get('measuredFeeder')
        misure.append({
            'id': misura['id'],
            'pagina': misura.get('page'),
            'strumento': misura.get('articleProposal'),
            'dispositivoProposto': proposta,
            'modoProposto': modo_proposto(progetto, proposta),
            'posizionamento': misura.get('placement'),
            'confermata': bool(misura.get('measuredFeederConfirmed')),
        })
    return {
        'modi': [
            {'id': ident, 'etichetta': testo, 'disegnabile': ident in MODI_DISEGNABILI,
             'motivo': None if ident in MODI_DISEGNABILI else 'Disegno sull\'arrivo linea ancora da integrare.'}
            for ident, testo in MODI.items()
        ],
        'strumenti': [{'articolo': a, 'descrizione': d} for a, d in STRUMENTI.items()],
        'generali': [_descrizione(n) for n in generali],
        'dispositivi': [_descrizione(n) for n in progetto.get('nodes', [])],
        'misure': misure,
        'radici': len(radici),
    }


def _risolvi_dispositivo(progetto: dict, modo: str, dispositivo: str | None) -> str:
    nodi = _nodi(progetto)
    radici = _radici(progetto)
    if modo == 'downstream_general':
        if dispositivo is None:
            if len(radici) != 1:
                raise ValueError('Generale non univoco: indicare l\'interruttore generale.')
            return radici[0]['id']
        if dispositivo not in nodi:
            raise ValueError('Interruttore non presente nel diagramma: ' + str(dispositivo))
        if nodi[dispositivo].get('parent'):
            raise ValueError('Il generale non può avere un\'alimentazione a monte: ' + str(nodi[dispositivo].get('sigla')))
        return dispositivo
    if modo == 'downstream_device':
        if dispositivo not in nodi:
            raise ValueError('Indicare l\'interruttore dell\'utenza misurata.')
        return dispositivo
    if modo == 'upstream_general':
        raise ValueError('Misura a monte del generale: disegno sull\'arrivo linea ancora da integrare.')
    raise ValueError('Posizione della misura sconosciuta: ' + str(modo))


def posiziona(progetto: dict, posizioni: list[dict]) -> dict:
    """Applica le scelte dell'operatore e restituisce una copia del progetto.

    Ogni voce: {misura?, modo, dispositivo?, strumento?, rapporto?, quantita?}.
    Senza `misura` si aggiunge un nuovo modulo (serve `strumento`).
    """
    risultato = copy.deepcopy(progetto)
    misure = risultato.setdefault('measurementAssemblies', [])
    per_id = {m['id']: m for m in misure}
    for voce in posizioni:
        modo = voce.get('modo')
        feeder = _risolvi_dispositivo(risultato, modo, voce.get('dispositivo'))
        misura = per_id.get(voce.get('misura'))
        if voce.get('misura') and misura is None:
            raise ValueError('Misura sconosciuta: ' + str(voce['misura']))
        if misura is None:
            strumento = voce.get('strumento')
            if strumento not in STRUMENTI:
                raise ValueError('Indicare lo strumento da inserire: ' + ', '.join(STRUMENTI))
            misura = {
                'id': uuid.uuid4().hex[:12], 'page': None, 'status': 'operator_placed', 'confirmed': True,
                'meterBox': None, 'ctGeometry': None, 'articleProposal': strumento, 'articleBox': None,
                'articleAssociation': 'operator', 'relatedQuotationArticles': [],
                'auxiliaryFeeds': {'L': None, 'N': None}, 'ratio': None, 'quantity': None,
                'voltageProtection': None, 'requiresIntegration': True,
                'limitations': ['Misura inserita dall\'operatore: protezione voltmetrica, rapporto TA e ausiliari da completare.'],
            }
            misure.append(misura)
            per_id[misura['id']] = misura
        elif voce.get('strumento'):
            if voce['strumento'] not in STRUMENTI:
                raise ValueError('Strumento sconosciuto: ' + str(voce['strumento']))
            misura['articleProposal'] = voce['strumento']
        misura['measuredFeeder'] = feeder
        misura['measuredFeederConfirmed'] = True
        misura['assignmentSource'] = 'operator'
        misura['placement'] = {'mode': modo, 'deviceId': feeder}
        for campo, chiave in (('rapporto', 'ratio'), ('quantita', 'quantity')):
            if voce.get(campo) is not None:
                misura[chiave] = voce[campo]
    occupati: dict[str, str] = {}
    for misura in misure:
        feeder = misura.get('measuredFeeder')
        if feeder in occupati:
            raise ValueError('Due misure sullo stesso interruttore: composizione ancora da definire.')
        occupati[feeder] = misura['id']
    return risultato
