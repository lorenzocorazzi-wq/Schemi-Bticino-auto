"""Apparecchi di riserva senza filo disegnato verso la barra.

Nel progetto una riserva (es. ``RISERVA``) puo' avere il solo simbolo, senza il
conduttore che sale alla barra. Il tracciamento geometrico la lascia senza
alimentazione, mentre elettricamente sta sulla barra delle utenze vicine.
Qui la proponiamo come figlia dello stesso padre del blocco adiacente, sullo
stesso foglio e dello stesso tipo, sempre da confermare. Nessun apparecchio con
un filo di ingresso riconosciuto viene toccato.
"""
from __future__ import annotations

MOTIVO = 'Riserva senza conduttore disegnato: alimentazione ereditata dal blocco adiacente dello stesso tipo. Confermare.'


def _pagina(nodo: dict):
    return nodo.get('evidence', {}).get('page')


def _asse(nodo: dict):
    return nodo.get('evidence', {}).get('axis')


def _discendenti(nodi: list[dict], radice: str) -> set[str]:
    trovati = {radice}
    cambiato = True
    while cambiato:
        cambiato = False
        for n in nodi:
            if n.get('parent') in trovati and n['id'] not in trovati:
                trovati.add(n['id'])
                cambiato = True
    return trovati


def adotta(nodi: list[dict]) -> list[str]:
    """Assegna un padre proposto alle riserve orfane. Restituisce gli id modificati."""
    modificati = []
    for nodo in nodi:
        if nodo.get('parent') or nodo.get('connectionStatus') != 'da_definire':
            continue
        if nodo.get('evidence', {}).get('connectionTrace'):
            continue
        asse = _asse(nodo)
        if asse is None:
            continue
        vicini = [m for m in nodi
                  if m is not nodo and m.get('parent') and _pagina(m) == _pagina(nodo)
                  and m.get('kind') == nodo.get('kind') and _asse(m) is not None]
        if not vicini:
            continue
        sinistri = [m for m in vicini if _asse(m) < asse]
        scelto = max(sinistri, key=_asse) if sinistri else min(vicini, key=lambda m: abs(_asse(m) - asse))
        if scelto['parent'] in _discendenti(nodi, nodo['id']):
            continue
        nodo['parent'] = scelto['parent']
        nodo['connectionStatus'] = 'proposta_da_adiacenza'
        nodo['connectionConfirmed'] = False
        nodo['connectionReview'] = {'status': 'proposed', 'reason': MOTIVO}
        nodo.setdefault('warnings', []).append(MOTIVO)
        modificati.append(nodo['id'])
    return modificati

