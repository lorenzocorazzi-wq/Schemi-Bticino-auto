"""Articoli rossi raster: isola il rosso, OCR per ritaglio, Claude vision solo sui dubbi.

Passi per pagina:
1. maschera dei pixel rossi e raggruppamento in ritagli (un riquadro per callout);
2. Tesseract su ogni ritaglio (righe + confidenza);
3. ritagli con codici non in listino o OCR incerto -> una sola richiesta Claude
   con le sole immagini dei ritagli (pochi token), risultato in cache;
4. ogni codice e' validato con catalogo/listino_bticino_2126.json.

Senza ANTHROPIC_API_KEY il passo 3 e' saltato: resta l'OCR locale.
"""
from __future__ import annotations

import base64, csv, hashlib, io, json, os, re, subprocess, urllib.request
from pathlib import Path

import numpy as np
import pymupdf
from PIL import Image

import listino

SCALA = 3
CELLA = 6            # px (a SCALA) per la griglia di raggruppamento
UNIONE = 3           # celle di dilatazione: unisce lettere e righe dello stesso callout
MIN_PIXEL = 25
CONF_MIN = 60
MAX_RITAGLI = 24     # per richiesta Claude
MODELLO = 'claude-haiku-5-5'
CACHE = Path(__file__).resolve().parent / 'cache_vision.json'
ROSSO = 0xff0000
_TOKEN = re.compile(r'[A-Z0-9][A-Z0-9/\-]{3,15}[A-Z0-9]')
_NO_WINDOW = getattr(subprocess, 'CREATE_NO_WINDOW', 0)


def maschera_rossa(rgb: np.ndarray) -> np.ndarray:
    r, g, b = (rgb[:, :, i].astype(int) for i in range(3))
    return (r > 150) & (g < 125) & (b < 125) & (r - g > 60)


def _gruppi(mask: np.ndarray) -> list[tuple[int, int, int, int]]:
    """Riquadri (x0,y0,x1,y1) in pixel dei gruppi di rosso vicini."""
    h, w = mask.shape
    gh, gw = -(-h // CELLA), -(-w // CELLA)
    pad = np.zeros((gh * CELLA, gw * CELLA), bool)
    pad[:h, :w] = mask
    griglia = pad.reshape(gh, CELLA, gw, CELLA).any(axis=(1, 3))
    visti = np.zeros_like(griglia)
    riquadri = []
    for y0, x0 in zip(*np.nonzero(griglia)):
        if visti[y0, x0]:
            continue
        pila = [(y0, x0)]
        visti[y0, x0] = True
        ys, xs = [y0], [x0]
        while pila:
            y, x = pila.pop()
            for yy in range(max(0, y - UNIONE), min(gh, y + UNIONE + 1)):
                for xx in range(max(0, x - UNIONE), min(gw, x + UNIONE + 1)):
                    if griglia[yy, xx] and not visti[yy, xx]:
                        visti[yy, xx] = True
                        pila.append((yy, xx))
                        ys.append(yy)
                        xs.append(xx)
        box = (min(xs) * CELLA, min(ys) * CELLA, min(w, (max(xs) + 1) * CELLA), min(h, (max(ys) + 1) * CELLA))
        if mask[box[1]:box[3], box[0]:box[2]].sum() >= MIN_PIXEL:
            riquadri.append(box)
    return riquadri


def ritagli(page) -> list[dict]:
    """Ritagli bianco/nero (testo rosso -> nero) con riquadro in coordinate PDF."""
    pix = page.get_pixmap(matrix=pymupdf.Matrix(SCALA, SCALA), alpha=False)
    rgb = np.frombuffer(pix.samples, np.uint8).reshape(pix.height, pix.width, 3)
    mask = maschera_rossa(rgb)
    if mask.sum() < MIN_PIXEL:
        return []
    risultato = []
    for x0, y0, x1, y1 in ((int(a), int(b), int(c), int(d)) for a, b, c, d in _gruppi(mask)):
        m = 4
        x0, y0, x1, y1 = max(0, x0 - m), max(0, y0 - m), min(mask.shape[1], x1 + m), min(mask.shape[0], y1 + m)
        img = Image.fromarray(np.where(mask[y0:y1, x0:x1], 0, 255).astype('uint8'))
        risultato.append({'pixel': (int(x0), int(y0)), 'box': [x0 / SCALA, y0 / SCALA, x1 / SCALA, y1 / SCALA], 'img': img})
    return risultato


def _png(img: Image.Image) -> bytes:
    buf = io.BytesIO()
    img.save(buf, 'PNG', optimize=True)
    return buf.getvalue()


def ocr(img: Image.Image, tesseract) -> list[dict]:
    """Righe OCR del ritaglio: testo, confidenza minima, riquadro (px ritaglio)."""
    if not tesseract or not Path(tesseract).is_file():
        return []
    bordo = Image.new('L', (img.width + 40, img.height + 40), 255)
    bordo.paste(img, (20, 20))
    run = subprocess.run([str(tesseract), 'stdin', 'stdout', '--psm', '6', '-c',
                          'tessedit_char_whitelist=ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789/-.', 'tsv'],
                         input=_png(bordo), stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                         creationflags=_NO_WINDOW, timeout=20)
    righe = {}
    for r in csv.DictReader(io.StringIO(run.stdout.decode('utf-8', errors='replace')), delimiter='\t'):
        testo = (r.get('text') or '').strip()
        if not testo:
            continue
        chiave = (r['block_num'], r['par_num'], r['line_num'])
        x, y, w, h = (int(r[k]) - (20 if k in ('left', 'top') else 0) for k in ('left', 'top', 'width', 'height'))
        riga = righe.setdefault(chiave, {'parole': [], 'conf': 100.0, 'box': [x, y, x + w, y + h]})
        riga['parole'].append(testo)
        riga['conf'] = min(riga['conf'], float(r['conf']))
        b = riga['box']
        riga['box'] = [min(b[0], x), min(b[1], y), max(b[2], x + w), max(b[3], y + h)]
    return [{'text': ' '.join(v['parole']), 'conf': v['conf'], 'box': v['box']} for v in righe.values()]


_SCAMBI = {'O': '0', '0': 'O', 'S': '5', '5': 'S', 'I': '1', '1': 'I'}


def correggi(codice: str) -> str:
    """Codice in listino; se assente prova prefisso LEG e un solo scambio O/0 S/5 I/1 (variante unica)."""
    if listino.esiste(codice):
        return codice
    if codice.startswith('LEG') and listino.esiste(codice[3:]):
        return codice[3:]
    varianti = set()
    for i, c in enumerate(codice):
        if c in _SCAMBI:
            v = codice[:i] + _SCAMBI[c] + codice[i + 1:]
            if listino.esiste(v):
                varianti.add(v)
    return varianti.pop() if len(varianti) == 1 else codice


def codici(testo: str) -> list[str]:
    return [correggi(c) for parola in str(testo or '').upper().replace('.', '').split() for c in _TOKEN.findall(parola)]


def _dubbio(righe: list[dict]) -> bool:
    if not righe:
        return True
    trovati = [(c, riga['conf']) for riga in righe for c in codici(riga['text'])]
    # Righe senza codici (sigle tipo F32) non contano; nessun codice nel ritaglio = dubbio.
    return not trovati or any(conf < CONF_MIN or not listino.esiste(c) for c, conf in trovati)


def _cache() -> dict:
    try:
        return json.loads(CACHE.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return {}


def _salva_cache(dati: dict) -> None:
    try:
        CACHE.write_text(json.dumps(dati, ensure_ascii=False, indent=0), encoding='utf-8')
    except OSError:
        pass


def configurato() -> bool:
    return bool(os.getenv('ANTHROPIC_API_KEY'))


def claude_vision(immagini: list[bytes], transport=None) -> tuple[list[list[str]], dict]:
    """Trascrive i ritagli: una lista di righe per immagine. Una sola richiesta."""
    content = []
    for i, png in enumerate(immagini):
        content.append({'type': 'text', 'text': f'#{i}'})
        content.append({'type': 'image', 'source': {'type': 'base64', 'media_type': 'image/png',
                                                    'data': base64.b64encode(png).decode('ascii')}})
    content.append({'type': 'text', 'text': (
        'Ogni immagine e\' un ritaglio con codici articolo BTicino (es. FT84C32, G701T/35N, 014310). '
        'Trascrivi ogni riga esattamente, senza correggere ne\' inventare. Illeggibile: "?". '
        'Rispondi solo JSON: {"r":[["riga1","riga2"],...]} un elemento per immagine, nell\'ordine.')})
    payload = {'model': os.getenv('ANTHROPIC_MODEL') or MODELLO, 'max_tokens': 60 + 40 * len(immagini),
               'messages': [{'role': 'user', 'content': content}]}
    request = urllib.request.Request('https://api.anthropic.com/v1/messages', data=json.dumps(payload).encode(),
                                     headers={'x-api-key': os.getenv('ANTHROPIC_API_KEY', ''),
                                              'anthropic-version': '2023-06-01', 'content-type': 'application/json'},
                                     method='POST')
    if transport is None:
        with urllib.request.urlopen(request, timeout=60) as response:
            answer = json.load(response)
    else:
        answer = transport(request)
    testo = ''.join(b.get('text', '') for b in answer.get('content', []) if b.get('type') == 'text').strip()
    testo = re.sub(r'^```(?:json)?\s*|\s*```$', '', testo)
    righe = json.loads(testo).get('r')
    if not isinstance(righe, list) or len(righe) != len(immagini):
        raise ValueError('Risposta Claude vision non allineata ai ritagli.')
    return [[str(x) for x in r] if isinstance(r, list) else [] for r in righe], answer.get('usage', {})


def _correggi(trovati: list[str]) -> tuple[list[str], list[dict]]:
    """Corregge i codici fuori listino con la sola confusione OCR univoca; il resto resta com'e'."""
    finali, correzioni = [], []
    for c in trovati:
        proposto = None if listino.esiste(c) else listino.correggi_ocr(c)
        if proposto:
            correzioni.append({'letto': c, 'proposto': proposto})
        finali.append(proposto or c)
    return finali, correzioni


def _valida(testo: str) -> dict:
    trovati, correzioni = _correggi(codici(testo))
    esito = {'codici': [c for c in trovati if listino.esiste(c)],
             'nonInListino': [{'codice': c, 'suggerimenti': listino.suggerimenti(c)} for c in trovati if not listino.esiste(c)]}
    if correzioni:
        esito['correzioniOcr'] = correzioni
    return esito


def _punteggio(righe: list[str]) -> tuple[int, int]:
    esiti = [_valida(r) for r in righe]
    return sum(len(e['codici']) for e in esiti), -sum(len(e['nonInListino']) for e in esiti)


def leggi_pagina(page, tesseract, vision: bool | None = None, transport=None, statistiche: dict | None = None) -> list[dict]:
    """Span rossi della pagina (stesso formato di pdf_import.spans) con codici validati."""
    stat = statistiche if statistiche is not None else {}
    pezzi = ritagli(page)
    for p in pezzi:
        p['ocr'] = ocr(p['img'], tesseract)
        p['png'] = _png(p['img'])
        p['hash'] = hashlib.sha1(p['png']).hexdigest()
    dubbi = [p for p in pezzi if _dubbio(p['ocr'])]
    stat.update(ritagli=len(pezzi), dubbi=len(dubbi), vision=0, cache=0)
    if vision is None:
        vision = configurato() or transport is not None
    if vision and dubbi:
        cache = _cache()
        da_chiedere = list({p['hash']: p for p in dubbi if p['hash'] not in cache}.values())
        stat['cache'] = sum(p['hash'] in cache for p in dubbi)
        for i in range(0, len(da_chiedere), MAX_RITAGLI):
            blocco = da_chiedere[i:i + MAX_RITAGLI]
            try:
                letture, uso = claude_vision([p['png'] for p in blocco], transport)
            except (OSError, ValueError, KeyError) as errore:
                stat['errore'] = str(errore)
                break
            stat['vision'] += len(blocco)
            stat.setdefault('usage', []).append(uso)
            for p, righe in zip(blocco, letture):
                cache[p['hash']] = righe
        if da_chiedere:
            _salva_cache(cache)
        for p in dubbi:
            p['vision'] = cache.get(p['hash'])
    spans = []
    for p in pezzi:
        righe_ocr = p['ocr'] or []
        righe_vis = [r for r in (p.get('vision') or []) if r.strip() and r.strip() != '?']
        # Scelta per ritaglio: vision solo se ha piu' codici in listino dell'OCR.
        usa_vision = bool(righe_vis) and _punteggio(righe_vis) > _punteggio([o['text'] for o in righe_ocr])
        x0, y0 = p['pixel']
        if usa_vision:
            alto = (p['box'][3] - p['box'][1]) / len(righe_vis)
            righe = [(t, [p['box'][0], p['box'][1] + i * alto, p['box'][2], p['box'][1] + (i + 1) * alto], None)
                     for i, t in enumerate(righe_vis)]
        else:
            righe = [(o['text'], [(x0 + o['box'][0]) / SCALA, (y0 + o['box'][1]) / SCALA,
                                  (x0 + o['box'][2]) / SCALA, (y0 + o['box'][3]) / SCALA], o['conf']) for o in righe_ocr]
        for testo, box, conf in righe:
            letti = _correggi(codici(testo))[0]
            spans.append({'text': ' '.join(letti) or testo, 'rawText': testo, 'box': box, 'color': ROSSO, 'source': 'claude_vision' if usa_vision else 'ocr',
                          'ocrConfidence': conf, 'ocrLines': [o['text'] for o in righe_ocr],
                          'visionLines': righe_vis or None, 'cropBox': p['box'], **_valida(testo)})
    return spans
